package uo.mp.util.collections;

import static org.junit.Assert.assertEquals;

import java.util.stream.Stream;

import org.junit.jupiter.api.Named;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import uo.mp.util.collections.impl.ArrayList;
import uo.mp.util.collections.impl.LinkedList;

/*
 * SCENARIOS
 * 	inList Get 0 returns elements at the head of a non-empty list 
 * 	getUpper Get returns last element in a non-empty list 
 * 	getIntermediate Get returns elements in the middle of a non-empty list with enough elements
 * 	emptyList Try to get element at position 0 in an empty list throws IndexOutOfBoundsException
 * 	emptyMinusOne Try to get element at position -1 in an empty list throws IndexOutOfBoundsException
 * 	emptyMinusOne Try to get element at position -1 in an list with elements throws IndexOutOfBoundsException
 * 	getSize Try to get element at position size() in an list with elements throws IndexOutOfBoundsException
 */
public class GetTests {

	public static Stream<Arguments> createLists() {
		  return Stream.of(
		      Arguments.of(Named.of("ArrayList", new ArrayList())),
		      Arguments.of(Named.of("LinkedList", new LinkedList()))
		  );
		}


	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void inList(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		
		assertEquals("first",list.get(0));
	}

	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists") 
	public void getUpper(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		
		assertEquals("third",list.get(2));
	}
	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists") 
	public void getIntermediate(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		list.add("fourth");
		list.add("fifth");
		
		assertEquals("third",list.get(2));
	}
	
	
	
	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyList(List list) {
		try {
			list.get(0);
		}
		catch(Exception e) {
			assertEquals("The element you want to get is out of the limits",e.getMessage());
		}
	}
	

	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyMinusOne(List list) {
		try {
			list.get(-1);
		}
		catch(Exception e) {
			assertEquals("The element you want to get is out of the limits",e.getMessage());
		}
	}

	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void nonEmptyMinusOne(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		list.add("fourth");
		list.add("fifth");
		try {
			list.get(-1);
		}
		catch(Exception e) {
			assertEquals("The element you want to get is out of the limits",e.getMessage());
		}
	}
	
	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void getSize(List list) {
		try {
			list.get(list.size());
		}
		catch(Exception e) {
			assertEquals("The element you want to get is out of the limits",e.getMessage());
		}
	}
	

}
