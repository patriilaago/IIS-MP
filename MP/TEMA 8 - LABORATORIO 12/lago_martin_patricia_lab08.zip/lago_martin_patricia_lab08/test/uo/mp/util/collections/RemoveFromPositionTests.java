package uo.mp.util.collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.stream.Stream;

import org.junit.jupiter.api.Named;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import uo.mp.util.collections.impl.ArrayList;
import uo.mp.util.collections.impl.LinkedList;

/*
 * SCENARIOS
 * 	delOnlyItem Remove element at position 0 from a list with one element returns the removed element and the list is empty
 * 	delFirst Remove element at position 0 from a non-empty list returns the element removed, size decreases and move the rest of elements one position to the left
 * 	delMiddle Remove from an existing position (in the middle of the list) returns the removed element, the element is removed, elements are shift one position to the left
 * 	delLast Remove last element returns the removed element and the element is removed, others remain at the same position
 * 	testLowerBound Try to remove element at position -1 throws IndexOutOfBoundsException
 * 	emptyList Try to remove element at position 0 in an empty list throws IndexOutOfBoundsException
 *	testUpperBound Try to remove element at position size() in a non-empty list throws IndexOutOfBoundsException
 */
public class RemoveFromPositionTests {
	public static Stream<Arguments> createLists() {
		  return Stream.of(
		      Arguments.of(Named.of("ArrayList", new ArrayList())),
		      Arguments.of(Named.of("LinkedList", new LinkedList()))
		  );
		}

	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void delOnlyItem(List list) {
		list.add("first");
		assertEquals("first",list.remove(0));
		assertEquals(true,list.isEmpty());
	}


	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void delFirst(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		assertEquals("first",list.remove(0));
		assertEquals(2,list.size());
	}
	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void delLast(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		
		int previous_position_first = list.indexOf("first");
		int previous_position_second = list.indexOf("second");
		
		assertEquals("third",list.remove(2));
		assertEquals(2,list.size());
		assertEquals(previous_position_first,list.indexOf("first"));
		assertEquals(previous_position_second,list.indexOf("second"));
	}

	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void delMiddle(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		
		int previous_position_first = list.indexOf("first");
		int previous_position_last = list.indexOf("third");
		
		assertEquals("second",list.remove(1));
		assertEquals(2,list.size());
		assertEquals(previous_position_first,list.indexOf("first"));
		assertEquals(previous_position_last-1,list.indexOf("third"));
	}
	
	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyList(List list) {
		try {
			list.remove(0);
		}
		catch(Exception e) {
			assertEquals("You can't remove an element from an empty list",e.getMessage());
		}
	}
	

	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void testUpperBound(List list) {
		list.add("first");
		try {
			list.remove(5);
			fail();
		}
		catch(Exception e) {
			assertEquals("The index of the element you want to remove is out of the limits",e.getMessage());
		}
	}
	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void testLowerBound(List list) {
		list.add("first");
		try {
			list.remove(-3);
			fail();
		}
		catch(Exception e) {
			assertEquals("The index of the element you want to remove is out of the limits",e.getMessage());
		}
	}
		

}
