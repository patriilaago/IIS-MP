package uo.mp.util.collections;

import static org.junit.Assert.assertEquals;
import java.util.stream.Stream;

import org.junit.jupiter.api.Named;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import uo.mp.util.collections.impl.ArrayList;
import uo.mp.util.collections.impl.LinkedList;

/*
 * SCENARIOS
 * 	emptyList An empty list does not contain an arbitrary element
 * 	notInList A list with several elements returns false to contain an element not in the list 
 * 	onlyElementInList A list with one element contains the element
 * 	isInList A list with several elements contains all its elements
 * 	emptyListDoesNotContainNull An empty list does not contains null
 * 	nullNotInList A list with elements does not contains null
 */
public class ContainsTests {
	public static Stream<Arguments> createLists() {
		  return Stream.of(
		      Arguments.of(Named.of("ArrayList", new ArrayList())),
		      Arguments.of(Named.of("LinkedList", new LinkedList()))
		  );
		}

	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyList(List list) {
		assertEquals(false,list.contains(null));
	}

	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void notInList(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		assertEquals(false,list.contains("hello"));
	}
	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void onlyElementInList(List list) {
		list.add("third");
		assertEquals(true,list.contains("third"));
	}
	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void isInList(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		assertEquals(true,list.contains("second"));
	}

	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyListDoesNotContainNull(List list) {
		assertEquals(false,	list.contains(null));	
	}
	
	/**
	 * GIVEN: 
	 * WHEN:    
	 * THEN: 
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void nullNotInList(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		assertEquals(false,list.contains(null));
	}
}
