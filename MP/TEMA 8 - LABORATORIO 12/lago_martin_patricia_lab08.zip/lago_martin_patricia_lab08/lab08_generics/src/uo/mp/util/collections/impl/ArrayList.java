package uo.mp.util.collections.impl;

import java.util.Iterator;

import java.util.NoSuchElementException;

import uo.mp.util.check.ArgumentChecks;
import uo.mp.util.collections.List;

public class ArrayList<T> implements List<T> {

	private final static int INITIAL_CAPACITY = 20;
	
	private T[] elements;
	private int numberOfElements;

	
	@SuppressWarnings("unchecked")
	public ArrayList(int capacity) {
		this.elements= (T[]) new Object[capacity];
		this.numberOfElements=0;
	}
	
	public ArrayList() {
		this(INITIAL_CAPACITY);
	}
	
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return numberOfElements;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return this.size() == 0;
	}
	
	@Override
	public boolean contains(Object o) {
		// TODO Auto-generated method stub
		return search(o) != -1;
	}
	
	private int search(Object o) {
		for (int i = 0; i < size(); i++) {
			if (elements[i].equals(o)) {
				return i;
			}
		}
		return -1;
	}

	@Override
	public boolean add(T element) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(element!=null, "The object you want to add cannot be null");
		if (size() >= this.elements.length) {
			this.moreMemory();
		}
		this.elements[size()] = element;
		this.numberOfElements++;
		return true;
	}

	private void moreMemory() {
		T[] aux = (T[]) new Object[2 * elements.length];
		System.arraycopy(elements, 0, aux, 0,elements.length);
		elements = aux;
	}
	
	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(o!=null, "The object you want to remove cannot be null");
		if(indexOf(o) != -1) {
			return remove(indexOf(o)) != null;
		} 
		else {
			return false;
		}
	}
	
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		for (int i = 0; i < size(); i++) {
			elements[i] = null;
		}
		numberOfElements = 0;
	}

	@Override
	public T get(int index) {
		// TODO Auto-generated method stub
		if(index<0 || index>=elements.length) {
			throw new IndexOutOfBoundsException("The index of the element you want to get is out of the limits");
		}
		return elements[index];
	}

	@Override
	public T set(int index, T element) {
		// TODO Auto-generated method stub
		if(index<0 || index>=elements.length) {
			throw new IndexOutOfBoundsException("The index of the element you want to get is out of the limits");
		}
		ArgumentChecks.isTrue(element != null, "The element you want to set cannot be null");
		T before = elements[index];
		elements[index] = element;
		return before;
	}

	@Override
	public void add(int index, T element) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(element!=null, "The object you want to add cannot be null");
		if(index<0 || index>=elements.length) {
			throw new IndexOutOfBoundsException("The index of the element you want to add is out of the limits");
		}
		if (size() >= this.elements.length) {
			this.moreMemory(); 
		}
		for(int i = size(); i > index; i--) {
			elements[i] = elements[i - 1];
		}
		elements[index] = element;
		numberOfElements++;
	}

	@Override
	public T remove(int index) {
		// TODO Auto-generated method stub
		if(index<0||index>numberOfElements) {
			throw new IndexOutOfBoundsException("The index of the element you want to remove is out of the limits");
		}
		if(this.isEmpty()) {
			throw new IndexOutOfBoundsException("You can't remove an element from an empty list");
		}
		T value = elements[index];
		for(int j=index; j < size()-1; j++){
			elements[j] = elements[j+1];
		}
		numberOfElements--;
		elements[numberOfElements] = null;
		return value;
	}

	@Override
	public int indexOf(Object o) {
		// TODO Auto-generated method stub
		return search(o);
	}

	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return  new ArrayListIterator();
	}

	private class ArrayListIterator implements Iterator<T>{

		private int current_index = 0;
		
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return current_index < numberOfElements;
		}

		@Override
		public T next() {
			// TODO Auto-generated method stub
			if(!hasNext()) {
				throw new NoSuchElementException("");
			}
			T next = elements[current_index];
			current_index++;
			return next;
		}
	}
}
