package uo.mp.util.collections.impl;

import java.util.Iterator;

import java.util.NoSuchElementException;
import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;
import uo.mp.util.collections.List;

public class LinkedList<T> implements List<T> {

	private static class Node {
		Object value;
		Node next;
		
		Node(Object value, Node next) {
		this.value = value;
		this.next = next;
		}
	}
	
	private Node head;
	private int numberOfElements;

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return this.numberOfElements;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return this.size() == 0;

	}

	@Override
	public boolean contains(T o) {
		// TODO Auto-generated method stub
		return search(o) != -1;
	}
	
	private int search(T o) {
		Node aux = head;
		int position = 0;
		while (aux != null && !aux.value.equals(o)) {
			aux = aux.next;
			position++;
		}
		return aux == null ? -1 : position;
	}

	private void addFirst(T element) {
		// TODO Auto-generated method stub
		this.head = new Node(element,this.head);
		numberOfElements++;
	}
	
	@Override
	public void add(int index,T element) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(element!=null, "The object you want to add cannot be null");
		if(index<0 || index>=size()) {
			throw new IndexOutOfBoundsException("The index of the element you want to add is out of the limits");
		}
		if (index==0)
			this.addFirst(element);
		else {
			Node previous = getNode(index-1);
			previous.next = new Node(element, previous.next);
			this.numberOfElements++;
		}
	}
	
	@Override
	public boolean add(T element) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(element!=null, "The object you want to add cannot be null");
		if (this.isEmpty()) {
			addFirst(element);
			return true;
		}
		else {	
			Node last = getNode(size()-1);
			last.next = new Node(element, null);
			this.numberOfElements++;
			return true;
		}
	}

	@Override
	public boolean remove(T o) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(o != null,"The object you want to remove cannot be null");
		int position = indexOf(o);
		if (position == -1) {
			return false;
		} 
		else {
			remove(position);
			return true;
		}
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		this.head = null;
		this.numberOfElements = 0;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T get(int index) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(index>=0 && index < size() && !isEmpty(), "The element you want to get is out of the limits");
		return (T) getNode(index).value;
	}
	
	private Node getNode(int index) {
		Node aux = head;
		for (int i = 0; i < index; i++) {
			aux = aux.next;
		}
		return aux;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T set(int index, T element) {
		// TODO Auto-generated method stub
		if(index<0||index>=numberOfElements) {
			throw new IndexOutOfBoundsException("The index of the element you want to get is out of the limits");
		}
		ArgumentChecks.isTrue(element != null, "The element you want to set cannot be null");
		getNode(index).value = element;
		return (T) this;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T remove(int index) {
		// TODO Auto-generated method stub
		if(this.isEmpty()) {
			throw new IndexOutOfBoundsException("You can't remove an element from an empty list");
		}
		if(index<0 || index>numberOfElements) {
			throw new IndexOutOfBoundsException("The index of the element you want to remove is out of the limits");
		}
		Object value;
		if (index == 0) { 
			value = head.value;
			head = head.next;
		} 
		else {
			Node previous = getNode(index - 1);
			value = (Node) previous.next.value;
			previous.next = previous.next.next;
		}
		this.numberOfElements--;
		return (T) value;
	}

	@Override
	public int indexOf(T o) {
		// TODO Auto-generated method stub
		return search(o);
	}

	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return new LinkedListIterator();
	}
	
	private class LinkedListIterator implements Iterator<T>{

		private Node current = head;
		
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return current != null;
		}

		@Override
		public T next() {
			// TODO Auto-generated method stub
			if(!hasNext()) {
				throw new NoSuchElementException("");
			}
			@SuppressWarnings("unchecked")
			T nodeToReturn = (T) current.value;
			current = current.next;
			return nodeToReturn;
		}
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("[");
		Node each = head;
		for(int i = 0; i < size(); i++) {
			sb.append(each.value);
				if(i < size() - 1) {
					sb.append(", ");
				}
			each = each.next;
		}
		sb.append("]");
		return sb.toString();
	}

	@Override
	public int hashCode() {
		return Objects.hash(head, numberOfElements);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (obj.getClass() == ArrayList.class) {
			ArrayList other = (ArrayList) obj;
			if (size() != other.size()) {
				return false;
			}
			if (isEmpty() && other.isEmpty()) {
				return true;
			}

			for (int i = 0; i < size(); i++) {
				if (!get(i).equals(other.get(i))) {
					return false;
				}
			}
			return true;
		}
		if (obj.getClass() == LinkedList.class) {
			List other = (List) obj;
			if (size() != other.size()) {
				return false;
			}
			if (isEmpty() && other.isEmpty()) {
				return true;
			}

			for (int i = 0; i < size(); i++) {
				if (!get(i).equals(other.get(i))) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

}
