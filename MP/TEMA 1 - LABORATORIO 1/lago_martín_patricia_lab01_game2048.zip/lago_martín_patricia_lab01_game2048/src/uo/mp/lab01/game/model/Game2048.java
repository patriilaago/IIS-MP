package uo.mp.lab01.game.model;

import uo.mp.util.check.ArgumentChecks;

/**
 * A simulation of the "2048" game, see http://juego2048.es/ Copyright (c) 2023 School of Computer Science - University
 * of Oviedo
 * The Game2048 class deals with the gameboard, setting up an array of elements and putting the array in a string. 
 * Most of the logic is also here, the class providing methods for spawning 2's at random locations, moving up, down, left and right, 
 * and letting players know when the game is over.
 * 
 * @author MP teachers
 * @version 1.0
 */
public class Game2048 {
	
	private int[][] board;
	private static final int MINIMUM_SIZE = 3;
	private static final int DEFAULT_SIZE = 3;
	private static final int MAXIMUM_SIZE = 5;
	private static final int EMPTY = 0;
	private static final int WINNING_NUMBER = 2048;
	
    /**
     * Creates a 3x3 board (default board) All cells set to 0
     */
    public Game2048() {
    	this.board=new int[DEFAULT_SIZE][DEFAULT_SIZE];
    }

    /**
     * Creates a squared board with the specified size, zeroes all its positions
     * 
     * @param size the desired size for the board
     * @throws IllegalArgumentException
     */
    public Game2048(int size) {
    	ArgumentChecks.isTrue(size >=3 && size<=5, "The size of the board cannot be lower than 3 or higher than 5");
    	this.board=new int[size][size];
    }

    /**
     * Constructor with an initial matrix as parameter Useful for testing purposes
     * 
     * @param board squared matrix, 3x3 to 5x5, containing only power-of-2 values. If size < 3 or size > 5 or some tile
     *              contains a non-power-of-2 value, default board is used instead
     * @throws IllegalArgumentException
     */
    Game2048(int[][] board) {
    	 this.board = board;
    }

    /**
     * @param n integer number >= 0
     * 
     * @return true if n is a power-of-2 number; false otherwise
     */
    private boolean powerOfTwoBitwise(int n) {
	return (n & n - 1) == 0;
    }

    /**
     * Returns the board. For testing purposes
     * 
     * @param the array
     */
    int[][] getBoard() {
	return null;
    }

    /**
     * A free position is a cell with a 0 value
     * 
     * @return true if there is no free positions on the board
     */
    public boolean isBoardFull() {
    	for(int i = 0 ; i<=board.length ; i++) {
    		for(int j = 0 ; j<=board.length ; j++) {
    			if(board[i][j]==0) {
    				return false;
    			}
    		}
    	}
    	return true;
    }

    /**
     * Pseudocode: For each row - slideRight (moves all non blank tiles to the right) - mergeRight (Move through the
     * vector; if two adjacent tiles are equal combines them doubling the value of the right tile and setting a zero on
     * the left one) - slideRight (again, as mergeRight has introduced new zeroes)
     */    
    public void moveRight() {
    	
    }

    private void slideRight(int[] vector) {
	// TODO
    }

    /**
     * @param vector to merge adding contiguous tiles to the right if contain the same value and replacing tile on the
     *               left with zero
     */
    private void mergeRight(int[] vector) {
	// TODO
    }

    /**
     * Move elements to the left with the same logic as in moveRight() By using the rotateBoard() method it is much
     * easier, it is a combination of rotate, rotate, move right, rotate, rotate
     */
    public void moveLeft() {
	rotateBoard();
	rotateBoard();
	moveRight();
	rotateBoard();
	rotateBoard();
    }

    /**
     * Move elements up with the same logic as in moveRight() By using the rotateBoard() method it is much easier, a
     * combination of rotations and moveRight
     */
    public void moveUp() {
	// TODO
    }

    /**
     * Move elements down with the same logic as in moveRight() By using the rotateBoard() method it is much easier, a
     * combination of rotations and moveRight
     */
    public void moveDown() {
	// TODO
    }

    /**
     * Rotates the board to the left (counterclockwise) Hint: create a new array and copy the values in the rotated
     * positions
     */
    private void rotateBoard() {
	// TODO
    }

    /**
     * Writes a 2 value on a random free tile, ensuring there is one.
     * 
     * @return true if there were a free tile; false otherwise.
     */
    public boolean next() {
		return false;
		//deberes
    }

    /**
     * @return a String with the content of the board to be printed out. Format each string so there are 5 spaces for
     *         every cell in the same row. Example: 2 2 0 2 0 0 2 0 2 will be
     *         "2....2....0....\n2....0....0....\n2....0....2...."
     */
    public String toString() {
    	return null;
    	//deberes
    }

    /**
     * @return true if the player has won; a tile contains 2048 
     */
    public boolean win() {
    	return false;
    	//deberes
    }

}
