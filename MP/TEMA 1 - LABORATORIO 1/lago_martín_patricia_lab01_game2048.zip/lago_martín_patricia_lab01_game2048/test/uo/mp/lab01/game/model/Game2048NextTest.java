package uo.mp.lab01.game.model;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Scenarios:
 * WRITE POSSIBLE SCENARIOS HERE
 */
public class Game2048NextTest {

    @Test
    /**
     * GIVEN:
     * WHEN:
     * THEN:
     */
    public void testScenario1() {
	fail();
    }

    @Test
    /**
     * GIVEN:
     * WHEN:
     * THEN:
     */
    public void testScenario2() {
	fail();
    }

    @Test
    /**
     * GIVEN:
     * WHEN:
     * THEN:
     */
    public void testScenario3() {
	fail();
    }

}
