package uo.mp.lab01.game.model;

import static org.junit.Assert.fail;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.Game2048;

/**
 * Scenarios:
 * - valid boards (lower limit 3, intermediate dimension 4, higher limit 5)
 * - invalid board: not squared
 * - invalid board: dimension under 3
 * - invalid board: dimension over 5
 * - invalid board: content not a multiple of 2
 * - invalid null board
 */
public class Game2048ConstructorWithBoardTest {

    @Test
    /**
     * GIVEN: A valid matrix 3x3
     * WHEN: Create a Game with the board
     * THEN: the board is set to the argument
     */
    public void testLowerLimit() {
	fail();
    }

    @Test
    /**
     * GIVEN: A valid matrix 5x5
     * WHEN: Create a Game with the board
     * THEN: the board is set to the argument
     */
    public void testUpperLimit() {
	fail();

    }

    @Test
    /**
     * GIVEN: A valid matrix 4x4
     * WHEN: Create a Game with the board
     * THEN: the board is set to the argument
     */
    public void testIntermediateDimension() {
	fail();

    }

    @Test
    /**
     * GIVEN: An invalid matrix 2x2
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    public void testDimensionUnder3() {
	fail();

    }

    @Test
    /**
     * GIVEN: An invalid matrix 6x6
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    public void testDimensionOver5() {
	fail();

    }

    @Test
    /**
     * GIVEN: An invalid matrix 3x4
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    public void testNotSquaredDimension() {
	fail();

    }

    @Test
    /**
     * GIVEN: An matrix 4x4 containing an invalid value (not power of 2)
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    public void testInvalidContent() {
	fail();

    }

    @Test
    /**
     * GIVEN: A null matrix
     * WHEN: Create a Game with the board
     * THEN: IllegalArgumentException expected
     */
    public void testNullContent() {

	Assertions.assertThrows(IllegalArgumentException.class, () -> {
	    new Game2048(null);
	}, "IllegalArgumentException was expected");
    }
}
