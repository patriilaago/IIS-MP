package uo.mp.lab01.game.model;

public class Game2048MoveDownTest {

}
