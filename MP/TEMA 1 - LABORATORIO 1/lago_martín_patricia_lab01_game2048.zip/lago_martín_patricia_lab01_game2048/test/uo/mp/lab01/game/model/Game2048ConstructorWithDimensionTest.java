package uo.mp.lab01.game.model;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Scenarios:
 * WRITE POSSIBLE SCENARIOS HERE
 */
public class Game2048ConstructorWithDimensionTest {

    @Test
    /**
     * GIVEN:
     * WHEN:
     * THEN:
     */
    public void testNameScenario1() {
	fail();
    }

    @Test
    /**
     * GIVEN:
     * WHEN:
     * THEN:
     */
    public void testNameScenario2() {
	fail();
    }

    @Test
    /**
     * GIVEN:
     * WHEN:
     * THEN:
     */
    public void testNameScenario3() {
	fail();
    }

    @Test
    /**
     * GIVEN:
     * WHEN:
     * THEN:
     */
    public void testNameScenario4() {
	fail();
    }

    @Test
    /**
     * GIVEN:
     * WHEN:
     * THEN:
     */
    public void testNameScenario5() {
	fail();
    }

}
