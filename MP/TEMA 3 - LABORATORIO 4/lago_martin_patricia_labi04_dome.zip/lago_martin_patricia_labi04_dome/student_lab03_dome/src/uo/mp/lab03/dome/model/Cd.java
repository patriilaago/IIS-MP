package uo.mp.lab03.dome.model;

import java.util.Objects;

import uo.mp.lab.util.check.ArgumentChecks;

/**
 *
 */
public class Cd extends ItemWithTime {

    private String artist;
    private int numberOfTracks;

    /**
     * Creates a new Cd with default values for gotIt and comment
     * 
     * @param theTitle  String for title
     * @param theArtist String for artist
     * @param tracks    integer for tracks
     * @param time      integer for time
     */
    public Cd(String theTitle, String theArtist, int tracks, int time) {
	super(theTitle, time);
	setArtist(theArtist);
	setNumberOfTracks(tracks);
    }

    /**
     * 
     * @param arg String with the new artist name
     * @throws IllegalArgumentException if the argument is null, 0-length or does not contain meaningful characters
     */
    private void setArtist(String arg) {
	ArgumentChecks.isTrue(arg != null && !arg.isBlank(), "Invalid artist");

	this.artist = arg;
    }

    /**
     * 
     * @param arg integer with the number of tracks in the CD
     * @throws IllegalArgumentException if the argument is is lower or equal zero
     */
    private void setNumberOfTracks(int arg) {
	ArgumentChecks.isTrue(arg > 0, "Invalid number of tracks");
	this.numberOfTracks = arg;
    }

    /**
     * @return artist's name
     */
    public String getArtist() {
	return this.artist;
    }

    /**
     * @return number of tracks
     */
    public int getNumberOfTracks() {
	return this.numberOfTracks;
    }

    /**
     * Prints the information about the cd
     * 
     * @param out a PrintStream to flush output
     */
    public String print() {
	StringBuilder sb = new StringBuilder();
	sb.append("Cd: " + getTitle() + ", ");
	sb.append("Artist: " + getArtist() + ", ");
	sb.append("Tracks: " + getNumberOfTracks() + ", ");
	sb.append("Playing time: " + getPlayingTime() + ", ");
	sb.append(super.getUserDetails());
	return sb.toString();
    }

    @Override
    public int hashCode() {
	final int prime = 31;
	int result = super.hashCode();
	result = prime * result + Objects.hash(artist, numberOfTracks);
	return result;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (!super.equals(obj))
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	Cd other = (Cd) obj;
	return Objects.equals(artist, other.artist) && numberOfTracks == other.numberOfTracks;
    }

    @Override
    public String toString() {
	return "Cd" + super.toString() + ", getArtist()=" + artist + ", getPlayingTime()=" + getPlayingTime() + "]";
    }

    @Override
    public String getResponsible() {
	return artist;
    }

    @Override
    public double getPrice() {
	return getBasePrice() + 2.0;
    }
}