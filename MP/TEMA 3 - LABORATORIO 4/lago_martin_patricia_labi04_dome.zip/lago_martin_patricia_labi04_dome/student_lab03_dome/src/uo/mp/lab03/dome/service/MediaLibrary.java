package uo.mp.lab03.dome.service;

import java.util.ArrayList;
import java.util.List;

import uo.mp.lab.util.check.ArgumentChecks;
import uo.mp.lab03.dome.model.Item;

public class MediaLibrary {

    private List<Item> catalogue = new ArrayList<>();

    /**
     * Method to add an item to the catalogue
     * 
     * @param theItem item to be added to the catalogue
     * @throws IllegalArgumentException if the item we want to add is null
     */
    public void add(Item theItem) {
	ArgumentChecks.isTrue(theItem != null, "The item you want to add to the catalogue cannot be null");
	if (!catalogue.contains(theItem)) {
	    catalogue.add(theItem);
	} else {
	}
    }

    /**
     * Method to see all the items available on the catalogue
     * 
     * @return list containing all the items from the catalogue
     */
    List<Item> getCatalogue() {
	return catalogue;
    }

    /**
     * Method that returns the number of items that are present on the catalogue and are also owned
     * 
     * @return number of items owned in the catalogue
     */
    public int numberOfItemsOwned() {
	int itemsOwned = 0;
	for (Item theItem : catalogue) {
	    if (theItem.getOwn() == true) {
		itemsOwned++;
	    }
	}
	return itemsOwned;
    }

    /**
     * Method that prints all the information about every item present on the catalogue
     * 
     * @param out a PrintStream to flush output
     */
    public String list() {
	StringBuilder sb = new StringBuilder();
	for (Item theItem : catalogue) {
	    sb.append(theItem.print());
	    sb.append("\n");
	}
	return sb.toString();
    }

    /**
     * Method to search for an item in the catalogue
     * 
     * @param theItem item we want to search for in the catalogue
     * @return Item in case it is found, null otherwise
     */
    public Item searchItem(Item theItem) {
	ArgumentChecks.isTrue(theItem != null, "The item you want to search for cannot be null");
	for (Item item : catalogue) {
	    if (item.equals(theItem)) {// equals only compares the content, not the reference
		return item;
	    }
	}
	return null;
    }

    /**
     * Method that returns an String containing all the responsibles (author, director or artist) of
     * the items that are available in the catalogue, separated by commas
     * 
     * @return String containing all the responsibles of the items that are present on the catalogue
     */
    public String getResponsibles() {
	StringBuilder result = new StringBuilder();
	for (Item theItem : catalogue) {
	    result.append(theItem.getResponsible());
	    result.append(", ");
	}
	return result.toString();
    }

    /**
     * Calculates the sum of the final prices of all items that are present on the catalogue
     * 
     * @return total price of all items in the library.
     */
    public double getTotalPrice() {
	double total_price = 0.0;
	for (Item theItem : catalogue) {
	    total_price = total_price + theItem.getPrice();
	}
	return total_price;
    }

    /**
     * 
     * @return string as the result of concatenating
     *         item’s code, joined by a dash (-).
     *         If there is no item, returns an empty string.
     */
    public String generateCodes() {
	StringBuilder sb = new StringBuilder();
	for (Item theItem : catalogue) {
	    sb.append(theItem.generateCode());
	    sb.append(catalogue.indexOf(theItem));
	    sb.append("-");
	}
	return sb.toString();
    }
}
