package uo.mp.lab03.dome.model;

public enum Platform {
    XBOX, NINTENDO, PLAYSTATION
}
