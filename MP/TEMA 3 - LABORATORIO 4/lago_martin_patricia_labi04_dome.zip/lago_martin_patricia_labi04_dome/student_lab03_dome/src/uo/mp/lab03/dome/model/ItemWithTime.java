package uo.mp.lab03.dome.model;

import java.util.Objects;

import uo.mp.lab.util.check.ArgumentChecks;

public abstract class ItemWithTime extends Item {

    private int playingTime;

    /**
     * Creates a new ItemWithTime with default values for gotIt and comment
     * 
     * @param theTitle
     * @param time
     */
    ItemWithTime(String theTitle, int time) {
	super(theTitle);
	setPlayingTime(time);
    }

    /**
     * 
     * @param arg integer with the playing time in the item
     * @throws IllegalArgumentException if the argument is lower or equal zero
     */
    private void setPlayingTime(int arg) {
	ArgumentChecks.isTrue(arg > 0, "Invalid playing time");
	this.playingTime = arg;
    }

    /**
     * @return playing time of the item
     */
    public int getPlayingTime() {
	return this.playingTime;
    }

    /**
     * Prints the information about the ItemWithTime
     * 
     * @param out a PrintStream to flush output
     */
    @Override
    public abstract String print();

    @Override
    public int hashCode() {
	final int prime = 31;
	int result = super.hashCode();
	result = prime * result + Objects.hash(playingTime);
	return result;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (!super.equals(obj))
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	ItemWithTime other = (ItemWithTime) obj;
	return playingTime == other.playingTime;
    }
}
