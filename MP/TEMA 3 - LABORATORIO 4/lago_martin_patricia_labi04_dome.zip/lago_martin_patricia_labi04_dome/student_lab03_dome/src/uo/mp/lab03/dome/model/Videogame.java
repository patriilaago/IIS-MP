package uo.mp.lab03.dome.model;

import java.util.Objects;

import uo.mp.lab.util.check.ArgumentChecks;

public class Videogame extends Item {

    private String author;
    private Platform platform;

    /**
     * Creates a new videogame with the default values for gotIt and comment
     * 
     * @param theTitle  String for title
     * @param theAuthor String for author
     * @param platform  platform for platform
     */
    public Videogame(String theTitle, String theAuthor, Platform platform) {
	super(theTitle);
	setAuthor(theAuthor);
	setPlatform(platform);
    }

    /**
     * 
     * @return the author of the videogame
     */
    public String getAuthor() {
	return author;
    }

    /**
     * 
     * @param author String with the new author
     * @throws IllegalArgumentException if the argument is null or in blank
     */
    public void setAuthor(String author) {
	ArgumentChecks.isTrue(author != null && !author.isBlank(), "The author of the game cannot be null or blank");
	this.author = author;
    }

    /**
     * 
     * @return the platform where you can play the videogame
     */
    public Platform getPlatform() {
	return platform;
    }

    /**
     * 
     * @param platform enum Platform with the new platform of the game
     */
    public void setPlatform(Platform platform) {
	this.platform = platform;
    }

    /**
     * Prints the information about the videogame
     * 
     * @param out a PrintStream to flush output
     */
    @Override
    public String print() {
	StringBuilder sb = new StringBuilder();
	sb.append("Videogame: " + getTitle() + ", ");
	sb.append("Author: " + getAuthor() + ", ");
	sb.append("Platform: " + getPlatform() + ", ");
	sb.append(super.getUserDetails());
	return sb.toString();
    }

    @Override
    public String getResponsible() {
	return author;
    }

    @Override
    public String toString() {
	return "Cd" + super.toString() + ", getAuthor() =" + author + "]";
    }

    @Override
    public int hashCode() {
	final int prime = 31;
	int result = super.hashCode();
	result = prime * result + Objects.hash(author, platform);
	return result;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (!super.equals(obj))
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	Videogame other = (Videogame) obj;
	return Objects.equals(author, other.author) && platform == other.platform;
    }

    @Override
    public double getPrice() {
	// TODO Auto-generated method stub
	return (getBasePrice() * 0.10) + getBasePrice();
    }
}
