package uo.mp.lab03.dome.model;

import java.util.Objects;

import uo.mp.lab.util.check.ArgumentChecks;

public class Dvd extends ItemWithTime {

    private String director;

    /**
     * Creates a new Dvd with default values for gotIt and comment
     * 
     * @param theTitle    String for title
     * @param theDirector String for director
     * @param time        integer for time
     */
    public Dvd(String theTitle, String theDirector, int time) {
	super(theTitle, time);
	setDirector(theDirector);
    }

    /**
     * 
     * @param arg String with the new director
     * @throws IllegalArgumentException if the argument is null, 0-length or does not contain meaningful characters
     */
    private void setDirector(String arg) {
	ArgumentChecks.isTrue(arg != null && !arg.isBlank(), "Invalid director");
	this.director = arg;
    }

    /**
     * @return the director of the dvd
     */
    public String getDirector() {
	return this.director;
    }

    /**
     * Prints the information about the dvd
     * 
     * @param out a PrintStream to flush output
     */
    public String print() {
	StringBuilder sb = new StringBuilder();
	sb.append("Dvd: " + getTitle() + ", ");
	sb.append("Director: " + getDirector() + ", ");
	sb.append("Playing time: " + getPlayingTime() + ", ");
	sb.append(super.getUserDetails());
	return sb.toString();
    }

    @Override
    public String toString() {
	return "Dvd" + super.toString() + ", getDirector()=" + director + ", getPlayingTime()=" + getPlayingTime()
		+ "]";
    }

    @Override
    public int hashCode() {
	final int prime = 31;
	int result = super.hashCode();
	result = prime * result + Objects.hash(director);
	return result;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (!super.equals(obj))
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	Dvd other = (Dvd) obj;
	return Objects.equals(director, other.director);
    }

    @Override
    public String getResponsible() {
	return director;
    }

    @Override
    public double getPrice() {
	return getBasePrice();
    }
}
