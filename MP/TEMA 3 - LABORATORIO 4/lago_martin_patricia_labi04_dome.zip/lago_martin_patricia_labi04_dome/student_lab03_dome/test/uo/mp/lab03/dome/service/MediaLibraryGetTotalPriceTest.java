package uo.mp.lab03.dome.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.lab03.dome.model.Cd;
import uo.mp.lab03.dome.model.Platform;
import uo.mp.lab03.dome.model.Videogame;

public class MediaLibraryGetTotalPriceTest {

    private Cd aCD;
    private String theTitle;
    private String theArtist;
    private int theTime;
    private int theTracks;
    private String theAuthor;
    private String theTitle_game;
    private Videogame game;

    @BeforeEach
    public void setUp() {
	theTitle = "Come Together";
	theArtist = "Beatles";
	theTime = 70;
	theTracks = 4;
	aCD = new Cd(theTitle, theArtist, theTracks, theTime);
	theTitle_game = "Animal Crossing";
	theAuthor = "Nintendo";
	game = new Videogame(theTitle_game, theAuthor, Platform.XBOX);
    }

    /**
     * GIVEN: a library with just one item with a base price of 2.5€
     * WHEN: getTotalPrice()
     * THEN: return just the price of the item with the corresponding tax
     */
    @Test
    public void oneItemPrice() {
	MediaLibrary ml = new MediaLibrary();
	aCD.setBasePrice(2.5);
	ml.add(aCD);
	assertEquals(4.5, ml.getTotalPrice());
    }

    /**
     * GIVEN: a library with just two items with a base price of 3€
     * WHEN: getTotalPrice()
     * THEN: return the price of the items from the catalogue with their corresponding tax
     */
    @Test
    public void twoItemsPrice() {
	MediaLibrary ml = new MediaLibrary();
	aCD.setBasePrice(3.0);
	game.setBasePrice(3.0);
	ml.add(aCD);
	ml.add(game);
	assertEquals(8.3, ml.getTotalPrice());
    }

    /**
     * GIVEN: a library with just two items with a base price of 3€
     * WHEN: getTotalPrice()
     * THEN: return the price of the items, in this case there are no items, so the price will be 0
     */
    @Test
    public void emptyLibraryPrice() {
	MediaLibrary ml = new MediaLibrary();
	assertEquals(0.0, ml.getTotalPrice());
    }
}
