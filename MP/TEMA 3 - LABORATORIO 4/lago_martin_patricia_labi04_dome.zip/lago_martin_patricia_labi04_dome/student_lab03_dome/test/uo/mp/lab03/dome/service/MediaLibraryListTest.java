package uo.mp.lab03.dome.service;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.lab03.dome.model.Cd;
import uo.mp.lab03.dome.model.Platform;
import uo.mp.lab03.dome.model.Videogame;

public class MediaLibraryListTest {

    private Cd aCD;
    private String theTitle;
    private String theArtist;
    private int theTime;
    private int theTracks;
    private String theAuthor;
    private String theTitle_game;
    private Videogame game;

    @BeforeEach
    public void setUp() {
	theTitle = "Come Together";
	theArtist = "Beatles";
	theTime = 70;
	theTracks = 4;
	aCD = new Cd(theTitle, theArtist, theTracks, theTime);
	theTitle_game = "Animal Crossing";
	theAuthor = "Nintendo";
	game = new Videogame(theTitle_game, theAuthor, Platform.XBOX);
    }

    /**
     * GIVEN: a library with a couple of elements
     * WHEN: call list()
     * THEN: returns in a string all the elements with their corresponding information
     */
    @Test
    public void elementsInCatalogue() {
	MediaLibrary ml = new MediaLibrary();
	ml.add(aCD);
	ml.add(game);
	assertEquals(
		"Cd: Come Together, Artist: Beatles, Tracks: 4, Playing time: 70, Got it: You do not own it, Comment: No comment"
			+ "\n"
			+ "Videogame: Animal Crossing, Author: Nintendo, Platform: XBOX, Got it: You do not own it, Comment: No comment"
			+ "\n",
		ml.list());
    }

    /**
     * GIVEN: an empty library
     * WHEN: call list()
     * THEN: returns an empty string
     */
    @Test
    public void emptyCatalogue() {
	MediaLibrary ml = new MediaLibrary();
	assertEquals("", ml.list());
    }

    /**
     * GIVEN: a library with just a single item
     * WHEN: call list()
     * THEN: returns a string with the corresponding information of the Cd (title, playing time...)
     */
    @Test
    public void oneItemInCatalogue() {
	MediaLibrary ml = new MediaLibrary();
	ml.add(aCD);
	assertEquals(
		"Cd: Come Together, Artist: Beatles, Tracks: 4, Playing time: 70, Got it: You do not own it, Comment: No comment"
			+ "\n",
		ml.list());
    }

}
