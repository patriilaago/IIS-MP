package uo.mp.lab03.dome.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.lab03.dome.model.Cd;
import uo.mp.lab03.dome.model.Platform;
import uo.mp.lab03.dome.model.Videogame;

public class MediaLibrarySearchItemTest {

    private Cd aCD;
    private String theTitle;
    private String theArtist;
    private int theTime;
    private int theTracks;
    private String theAuthor;
    private String theTitle_game;
    private Videogame game;

    @BeforeEach
    public void setUp() {
	theTitle = "Come Together";
	theArtist = "Beatles";
	theTime = 70;
	theTracks = 4;
	aCD = new Cd(theTitle, theArtist, theTracks, theTime);
	theTitle_game = "Animal Crossing";
	theAuthor = "Nintendo";
	game = new Videogame(theTitle_game, theAuthor, Platform.XBOX);
    }

    /**
     * GIVEN: a library with a cd and a game
     * WHEN: call searchItem() for the cd and the videogame
     * THEN: return cd and game
     */
    @Test
    public void itemFound() {
	MediaLibrary ml = new MediaLibrary();
	ml.add(aCD);
	ml.add(game);
	assertEquals(game, ml.searchItem(game));
	assertEquals(aCD, ml.searchItem(aCD));
    }

    /**
     * GIVEN: an empty library
     * WHEN: call searchItem() for the cd
     * THEN: return null
     */
    @Test
    public void itemNotFound() {
	MediaLibrary ml = new MediaLibrary();
	ml.add(aCD);
	assertEquals(null, ml.searchItem(game));
    }

    /**
     * GIVEN: an empty library
     * WHEN: call searchItem() for null
     * THEN: throws IllegalArgumentException
     */
    @Test
    public void itemNull() {
	MediaLibrary ml = new MediaLibrary();
	try {
	    ml.searchItem(null);
	    fail("Exception expected");
	} catch (Exception e) {
	    assertEquals("The item you want to search for cannot be null", e.getMessage());
	}
    }

    /**
     * GIVEN: an empty library where we add a cd
     * WHEN: call searchItem() for another cd with the same content as the previous one
     * THEN: returns it is not null
     */
    @Test
    public void matchDifferentReference() {
	MediaLibrary ml = new MediaLibrary();
	Cd cd = new Cd("title", "artist", 1, 2);
	ml.add(cd);

	assertNotNull(ml.searchItem(new Cd("title", "artist", 1, 2)));// different from cd
    }
}
