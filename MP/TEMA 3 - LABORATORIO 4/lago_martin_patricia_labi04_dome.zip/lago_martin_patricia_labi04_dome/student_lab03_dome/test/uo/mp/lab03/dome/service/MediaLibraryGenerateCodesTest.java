package uo.mp.lab03.dome.service;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.lab03.dome.model.Cd;
import uo.mp.lab03.dome.model.Platform;
import uo.mp.lab03.dome.model.Videogame;

public class MediaLibraryGenerateCodesTest {

    private Cd aCD;
    private String theTitle;
    private String theArtist;
    private int theTime;
    private int theTracks;
    private String theAuthor;
    private String theTitle_game;
    private Videogame game;

    @BeforeEach
    public void setUp() {
	theTitle = "Come Together";
	theArtist = "Beatles";
	theTime = 70;
	theTracks = 4;
	aCD = new Cd(theTitle, theArtist, theTracks, theTime);
	theTitle_game = "Animal Crossing";
	theAuthor = "Nintendo";
	game = new Videogame(theTitle_game, theAuthor, Platform.XBOX);
    }

    /**
     * GIVEN: a library with just one item
     * WHEN: generateCodes()
     * THEN: returns the code of the item and its position in the catalogue
     */
    @Test
    public void oneItemCode() {
	MediaLibrary ml = new MediaLibrary();
	ml.add(aCD);
	assertEquals("Com0-", ml.generateCodes());
    }

    /**
     * GIVEN: an empty library
     * WHEN: generateCodes()
     * THEN: returns empty String
     */
    @Test
    public void emptyLibrary() {
	MediaLibrary ml = new MediaLibrary();
	assertEquals("", ml.generateCodes());
    }

    /**
     * GIVEN:a library with two items
     * WHEN: generateCodes()
     * THEN: returns in a string the codes of each
     * item and their position in the catalogue
     */
    @Test
    public void twoItemsCode() {
	MediaLibrary ml = new MediaLibrary();
	ml.add(game);
	ml.add(aCD);
	assertEquals("Ani0-Com1-", ml.generateCodes());
    }
}
