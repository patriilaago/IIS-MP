package uo.mp.find.error.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PlaneAddPassengerTests {

    @Test
    /**
     * GIVEN: empty plane
     * WHEN: add person
     * THEN: person in plane
     */
    void emptyPlane() {
	Plane p = new Plane();
	p.setPassengers(Util.empty); 
	p.addPassenger(new Person ("new person", 10));
	
	assertTrue(p.getPassengers().size() == 1);
    }

    @Test
    /**
     * GIVEN: non empty plane
     * WHEN: add person
     * THEN: one more person in plane
     */
    void nonEmptyPlane() {
	Plane p = new Plane();
	p.setPassengers(Util.empty); 
	p.addPassenger(new Person ("new person", 10));
	p.addPassenger(new Person ("other new person", 20));
	
	assertTrue(p.getPassengers().size() == 2);
    }
    
    
}
