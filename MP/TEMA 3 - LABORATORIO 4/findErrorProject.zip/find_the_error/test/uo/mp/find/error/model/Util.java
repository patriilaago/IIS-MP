package uo.mp.find.error.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Util {

    public static List<Person> three = Arrays
	.asList(new Person("person1", 1), new Person("person2", 2),
		new Person("person3", 3));

    public static List<Person> empty = new ArrayList<>();
}
