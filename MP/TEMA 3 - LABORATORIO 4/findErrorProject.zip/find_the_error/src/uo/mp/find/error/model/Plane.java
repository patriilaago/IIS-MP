package uo.mp.find.error.model;

import java.util.ArrayList;
import java.util.List;

public class Plane {

    private List<Person> passengers = new ArrayList<>();

    public List<Person> getPassengers() {
	return passengers;
    }

    public void setPassengers(List<Person> passengers) {
	this.passengers = passengers;
    }

    public void addPassenger(Person p) {
	passengers
	    .add(p);
    }

    @Override
    public String toString() {
	return "Plane [passengers=" + passengers + "]";
    }

}
