package uo.mp.transaction.validator.file;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.transaction.model.BankTransferTransaction;
import uo.mp.transaction.model.ClientType;
import uo.mp.transaction.model.CreditCardTransaction;
import uo.mp.transaction.model.Transaction;
import uo.mp.transaction.validator.exception.InvalidLineException;

public class TransactionLoaderLoadTest {

	private List<Transaction> t;
	private CreditCardTransaction card;
	private BankTransferTransaction bank;
	
	@BeforeEach
	public void setUp() {
		t = new LinkedList<>();
	}
	
	@Test
	void loadFile() throws IOException, InvalidLineException {
		TransactionLoader loader = new TransactionLoader("input_transactions.trx");
		card = new CreditCardTransaction("2021/05/01", "3531331821537868", 3333.0, "Alibaba Supermarket", "2021/12/01", 1000.0);
		bank = new BankTransferTransaction("2021/05/08", "ES0310250124910021214445", 150.0, "Car repairing at Caris", ClientType.NORMAL);
		t.add(card);
		t.add(bank);
		assertEquals(loader.load().get(0).getNumber(),card.getNumber());
		assertEquals(loader.load().get(0).getDate(),card.getDate());
		assertEquals(loader.load().get(0).getDescription(),card.getDescription());
		assertEquals(loader.load().get(0).getAmount(),card.getAmount());
		
		assertEquals(loader.load().get(1).getNumber(),bank.getNumber());
		assertEquals(loader.load().get(1).getDate(),bank.getDate());
		assertEquals(loader.load().get(1).getDescription(),bank.getDescription());
		assertEquals(loader.load().get(1).getAmount(),bank.getAmount());
	}

}
