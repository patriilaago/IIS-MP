package uo.mp.transaction.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.transaction.validator.exception.TransactionException;

public class TransactionValidateTest {

	private CreditCardTransaction card;
	private BankTransferTransaction bank;
	private String date_card;
	private String date_bank;
	private String number_card;
	private String number_bank;
	private double amount_card;
	private double amount_bank;
	private String description_card;
	private String description_bank;
	private String expiration_card;
	private double max_card;
	private ClientType type_bank;
	
	@BeforeEach
	public void setUp() {
		date_card = "2021/05/08";
		date_bank = "2022/05/08";
		number_card = "5552468190471987";
		number_bank = "ES0712452342121241551584";
		amount_card = 1100.0;
		amount_bank = 800.0 ;
		description_card = "Carrefour Travel Agency";
		description_bank = "Shopping at CFRD";
		expiration_card = "2022/05/08";
		max_card = 1200.0;
		type_bank = ClientType.NORMAL;
		card = new CreditCardTransaction(date_card, number_card, amount_card, description_card, expiration_card, max_card);
		bank = new BankTransferTransaction(date_bank, number_bank, amount_bank, description_bank, type_bank);
	}
	
	@Test
	void invalidAmountBank() {
		bank.setAmount(1500.0);
		try {
			bank.validate();
		}
		catch(TransactionException e) {
			assertEquals(e.getMessage(),"ERROR Please mind this error: EXCEEDS CLIENT LIMIT");
		}
	}

	@Test
	public void AmountBiggerThanMaxCard() {
		card.setMaximumAmount(900.0);
		try {
			card.validate();
		}
		catch(TransactionException e) {
			assertEquals(e.getMessage(),"ERROR Please mind this error: EXCEEDS_OPERATION_LIMIT");
		}
	}
	
	@Test
	public void DateBiggerThanExpiration() {
		card.setExpirationDate("2004/10/08");
		try {
			card.validate();
		}
		catch(TransactionException e) {
			assertEquals(e.getMessage(),"ERROR Please mind this error: EXPIRED_CARD");
		}
	}
	
	@Test
	public void invalidIBAN() {
		bank.setNumber("33");
		try {
			card.validate();
		}
		catch(TransactionException e) {
			assertEquals(e.getMessage(),"ERROR Please mind thsi error: INVALID_CARD");
		}
	
	}
}
