package uo.mp.transaction.validator;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.transaction.model.BankTransferTransaction;
import uo.mp.transaction.model.ClientType;
import uo.mp.transaction.model.CreditCardTransaction;
import uo.mp.transaction.model.Transaction;

public class TransactionValidatorValidateTest {

	private CreditCardTransaction card;
	private BankTransferTransaction bank;
	private String date_card;
	private String date_bank;
	private String number_card;
	private String number_bank;
	private double amount_card;
	private double amount_bank;
	private String description_card;
	private String description_bank;
	private String expiration_card;
	private double max_card;
	private ClientType type_bank;
	private List<Transaction> transactions;
	
	@BeforeEach
	public void setUp() {
		date_card = "2021/05/08";
		date_bank = "2022/05/08";
		number_card = "5552468190471987";
		number_bank = "ES0712452342121241551584";
		amount_card = 1100.0;
		amount_bank = 800.0 ;
		description_card = "Carrefour Travel Agency";
		description_bank = "Shopping at CFRD";
		expiration_card = "2022/05/08";
		max_card = 1200.0;
		type_bank = ClientType.NORMAL;
		card = new CreditCardTransaction(date_card, number_card, amount_card, description_card, expiration_card, max_card);
		bank = new BankTransferTransaction(date_bank, number_bank, amount_bank, description_bank, type_bank);
		transactions = new ArrayList<>();
	}
	
	@Test
	void everythingIsValid() {
		TransactionValidator validator = new TransactionValidator();
		transactions.add(bank);
		transactions.add(card);
		validator.add(transactions);
		validator.validate();
		assertEquals(validator.getValidTransactions(),transactions);
	}
	
	@Test
	void cardIsValidBankNot() {
		TransactionValidator validator = new TransactionValidator();
		bank.setAmount(5000.0);
		transactions.add(bank);
		transactions.add(card);
		validator.add(transactions);
		validator.validate();
		List<Transaction> invalid = new ArrayList<>();
		invalid.add(bank);
		List<Transaction> valid = new ArrayList<>();
		valid.add(card);
		assertEquals(validator.getValidTransactions(),valid);
		assertEquals(validator.getInvalidTransactions(),invalid);
	}
	
	@Test
	void bankIsValidCardNot() {
		TransactionValidator validator = new TransactionValidator();
		card.setAmount(33.0);
		card.setMaximumAmount(15.0);
		transactions.add(bank);
		transactions.add(card);
		validator.add(transactions);
		validator.validate();
		List<Transaction> invalid = new ArrayList<>();
		invalid.add(card);
		List<Transaction> valid = new ArrayList<>();
		valid.add(bank);
		assertEquals(validator.getValidTransactions(),valid);
		assertEquals(validator.getInvalidTransactions(),invalid);
	}
	
	@Test
	void nothingIsValid() {
		TransactionValidator validator = new TransactionValidator();
		card.setDate("2015/07/24");
		card.setExpirationDate("1998/02/01");
		bank.setAmount(44000.0);
		transactions.add(bank);
		transactions.add(card);
		validator.add(transactions);
		validator.validate();
		assertEquals(validator.getInvalidTransactions(),transactions);
	}
}
