package uo.mp.transaction.validator.exception;

public class InvalidLineException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public InvalidLineException(int line, String errorDescription) {
		super(String.format("PARSING ERROR at %d: %s",line,errorDescription));
	}

}
