package uo.mp.transaction.validator.file;

import java.io.IOException;
import java.util.List;

import uo.mp.transaction.file.ZipFileUtil;
import uo.mp.transaction.model.Transaction;
import uo.mp.transaction.validator.serialize.TransactionSerializer;


public class ValidTransactionWriter {

	private String fileName;

	public ValidTransactionWriter(String fileName) {
		this.fileName = fileName;
	}

	public void save(List<Transaction> validTrx) throws IOException {
		List<String> lines = new TransactionSerializer().serialize( validTrx );
		new ZipFileUtil().writeLines(  fileName + ".gz", lines );
	}

}
