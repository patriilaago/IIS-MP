package uo.mp.transaction.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import uo.mp.transaction.validator.exception.TransactionException;

public class FileUtil {

	public void writeLines(String pathToFile, List<String> lines) throws IOException, FileNotFoundException {
		// TODO Auto-generated method stub
		try(BufferedWriter writer = new BufferedWriter(new FileWriter(pathToFile))){
			for(String line : lines) {
				writer.write(line);
				writer.newLine();//true significa que esrcibe a continuación de lo que ya había
			}
		}
		catch(IOException e) {
			throw new RuntimeException("Error en lectura de datos");
		}
	}

	public List<String> readLines(String fileName) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		List<String> result = new LinkedList<>();
		try(BufferedReader reader = new BufferedReader(new FileReader(fileName))){
			while(reader.ready()) {//mientras tengamos datos para leer
				String line = reader.readLine();
				result.add(line);
			}
		}
		catch(FileNotFoundException e) {
			throw new TransactionException("FILE NOT FOUND, MAY BE CORRUPT");
		}
		
		return result;
	}
}
