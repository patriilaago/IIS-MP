package uo.mp.transaction.validator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import uo.mp.transaction.model.Transaction;
import uo.mp.transaction.validator.exception.TransactionException;
import uo.mp.transaction.validator.sort.OrderDateNumber;
import uo.mp.util.check.ArgumentChecks;

public class TransactionValidator {

	private List<Transaction> valids = new ArrayList<Transaction>();
	private List<Transaction> invalids = new ArrayList<Transaction>();
	private List<Transaction> copyList = new ArrayList<Transaction>();
	
	public void add(List<Transaction> trxs) {
		ArgumentChecks.isNotNull(trxs);
		for(Transaction t : trxs) {
			if(!copyList.contains(t)) {
				copyList.add(t);
			}
			else {
				throw new TransactionException("TWO TRANSACTIONS ARE REPEATED, FILE IS CORRUPT");
			}
		}
		Collections.sort(copyList, new OrderDateNumber());
	}

	public void validate() {
		// TODO 
		for(Transaction transaction : copyList) {
			try {
				transaction.validate();
				valids.add(transaction);
			}
			catch(TransactionException e) {
				transaction.addFault(e.getMessage());
				invalids.add(transaction);
			}
		}
	}

	public List<Transaction> getInvalidTransactions() {
		// TODO 
		return new ArrayList<>(invalids);
	}

	public List<Transaction> getValidTransactions() {
		// TODO 
		return new ArrayList<>(valids);
	}
}
