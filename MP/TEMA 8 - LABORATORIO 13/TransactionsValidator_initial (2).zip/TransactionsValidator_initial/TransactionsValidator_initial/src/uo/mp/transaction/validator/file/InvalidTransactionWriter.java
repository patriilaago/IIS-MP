package uo.mp.transaction.validator.file;


import java.io.IOException;
import java.util.List;

import uo.mp.transaction.file.FileUtil;
import uo.mp.transaction.model.Transaction;
import uo.mp.transaction.validator.serialize.TransactionSerializer;


public class InvalidTransactionWriter {

	private String fileName;

	public InvalidTransactionWriter(String fileName) {
		this.fileName = fileName;
	}

	public void save(List<Transaction> invalidTrx) throws IOException {
		List<String> lines = new TransactionSerializer().serialize( invalidTrx );
		new FileUtil().writeLines( fileName + ".invalid.trx", lines );
	}
}
