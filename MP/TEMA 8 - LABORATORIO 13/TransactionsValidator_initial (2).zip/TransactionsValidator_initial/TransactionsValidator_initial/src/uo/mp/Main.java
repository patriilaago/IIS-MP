package uo.mp;

import java.io.IOException;

import uo.mp.transaction.TransactionProcessor;
import uo.mp.transaction.validator.exception.InvalidLineException;

public class Main {

	private static final String TRX_FILE_NAME = "input_transactions.trx";
//	private static final String TRX_FILE_NAME = "input_transactions_with_parsing_errors.trx";
//	private static final String TRX_FILE_NAME = "input_transactions_with_repeated_abort.trx";
//	private static final String TRX_FILE_NAME = "HELLO.trx";
	
	public static void main(String[] args) {
		new Main().run();
	}

	private void run() {
		try {
			new TransactionProcessor().process(TRX_FILE_NAME);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(InvalidLineException ex) {
			
		}
	}
}
