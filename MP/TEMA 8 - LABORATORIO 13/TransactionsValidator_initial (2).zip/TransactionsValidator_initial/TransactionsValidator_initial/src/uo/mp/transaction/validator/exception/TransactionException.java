package uo.mp.transaction.validator.exception;

public class TransactionException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public TransactionException(String theDescription) {
		super(String.format("ERROR Please mind this error: %s", theDescription));
	}

}
