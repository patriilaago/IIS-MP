package uo.mp.transaction.validator.serialize;

import java.util.ArrayList;
import java.util.List;

import uo.mp.transaction.model.Transaction;

public class TransactionSerializer {

	public List<String> serialize(List<Transaction> validTrx) {
		// TODO Auto-generated method stub
		List<String> serializedTransactions = new ArrayList<>();
		for(Transaction transaction : validTrx) {
			serializedTransactions.add(transaction.serialize());
		}
		return serializedTransactions;
	}

}
