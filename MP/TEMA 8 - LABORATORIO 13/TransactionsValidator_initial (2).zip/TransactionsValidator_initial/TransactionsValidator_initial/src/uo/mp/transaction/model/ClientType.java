package uo.mp.transaction.model;

public enum ClientType {

	NORMAL, PREMIUM
}
