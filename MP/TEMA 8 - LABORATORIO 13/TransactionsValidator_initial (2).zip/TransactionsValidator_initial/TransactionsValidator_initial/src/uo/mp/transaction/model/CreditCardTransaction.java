package uo.mp.transaction.model;

import java.util.Objects;

import uo.mp.transaction.model.util.Lhun;
import uo.mp.transaction.validator.exception.TransactionException;

public class CreditCardTransaction extends Transaction{

	private String expirationDate;
	private double maximumAmount;
	
	public CreditCardTransaction(String date, String number, double amount, String description, String expirationDate, double maxAmount ) {
		super(date, number, amount, description);
		// TODO Auto-generated constructor stub
		setExpirationDate(expirationDate);
		setMaximumAmount(maxAmount);
	}

	@Override
	public void validate() throws TransactionException {
		// TODO Auto-generated method stub
		if(!Lhun.isValid(getNumber())) {
			throw new TransactionException("INVALID_CARD");
		}
		if(getAmount()>getMaximumAmount()) {
			throw new TransactionException("EXCEEDS_OPERATION_LIMIT");
		}
		if(getDate().compareTo(getExpirationDate())==1) {
			throw new TransactionException("EXPIRED_CARD");
		}
	}

	@Override
	public String serialize() {
		// TODO Auto-generated method stub
		return "cc;" + this.getDate() + ";" + this.getNumber() + ";" + this.getExpirationDate() + ";" + this.getMaximumAmount() + ";"
		+ this.getAmount() + ";" + this.getDescription();
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public double getMaximumAmount() {
		return maximumAmount;
	}

	public void setMaximumAmount(double maximumAmount) {
		this.maximumAmount = maximumAmount;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(expirationDate, maximumAmount);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CreditCardTransaction other = (CreditCardTransaction) obj;
		return Objects.equals(expirationDate, other.expirationDate)
				&& Double.doubleToLongBits(maximumAmount) == Double.doubleToLongBits(other.maximumAmount);
	}
}
