package uo.mp.transaction.model;

import java.util.Objects;

import uo.mp.transaction.model.util.IBAN;
import uo.mp.transaction.validator.exception.TransactionException;

public class BankTransferTransaction extends Transaction{

	private ClientType typeOfClient;
	private final static int MAXIMUM_AMOUNT_NORMAL_CLIENT = 1000;
	
	public BankTransferTransaction(String date, String number, double amount, String description, ClientType typeOfClient) {
		super(date, number, amount, description);
		// TODO Auto-generated constructor stub
		setTypeOfClient(typeOfClient);
	}

	@Override
	public void validate() throws TransactionException {
		// TODO Auto-generated method stub
		if(getTypeOfClient().equals(ClientType.NORMAL)) {
			if(getAmount()>MAXIMUM_AMOUNT_NORMAL_CLIENT) {
				throw new TransactionException("EXCEEDS CLIENT LIMIT");
			}	
		}
		if(!IBAN.isValid(getNumber())) {
			throw new TransactionException("INVALID_IBAN");
		}
	}

	@Override
	public String serialize() {
		// TODO Auto-generated method stub
		return "acc;" + this.getDate() + ";" + this.getNumber() + ";" + this.getTypeOfClient() + ";" + this.getAmount()
				+ ";" + this.getDescription();
	}

	public ClientType getTypeOfClient() {
		return typeOfClient;
	}

	public void setTypeOfClient(ClientType typeOfClient) {
		this.typeOfClient = typeOfClient;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(typeOfClient);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankTransferTransaction other = (BankTransferTransaction) obj;
		return typeOfClient == other.typeOfClient;
	}	
}
