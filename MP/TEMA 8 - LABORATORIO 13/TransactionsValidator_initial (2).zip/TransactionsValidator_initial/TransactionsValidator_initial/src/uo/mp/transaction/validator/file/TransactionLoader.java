package uo.mp.transaction.validator.file;

import java.io.IOException;
import java.util.List;

import uo.mp.transaction.file.FileUtil;
import uo.mp.transaction.model.Transaction;
import uo.mp.transaction.validator.exception.InvalidLineException;
import uo.mp.transaction.validator.parser.TransactionParser;

public class TransactionLoader {

	private String fileName;

	public TransactionLoader(String fileName) {
		this.fileName = fileName;
	}

	public List<Transaction> load() throws IOException, InvalidLineException {
		List<String> lines = new FileUtil().readLines( fileName );
		return new TransactionParser().parse( lines );
	}

}
