package uo.mp.transaction;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import uo.mp.transaction.file.FileLogger;
import uo.mp.transaction.model.Transaction;
import uo.mp.transaction.validator.TransactionValidator;
import uo.mp.transaction.validator.exception.InvalidLineException;
import uo.mp.transaction.validator.exception.TransactionException;
import uo.mp.transaction.validator.file.InvalidTransactionWriter;
import uo.mp.transaction.validator.file.TransactionLoader;
import uo.mp.transaction.validator.file.ValidTransactionWriter;

public class TransactionProcessor {

	private TransactionValidator validator;
	private FileLogger logger = new FileLogger("logger.txt");

	public void process(String trxFileName) throws IOException, InvalidLineException {
		
		List<Transaction> trxs = new ArrayList<>();
		try {
			trxs = new TransactionLoader( trxFileName ).load(); //BIEN
		}
		catch(FileNotFoundException e) {
			System.out.println(e.getMessage());
			logger.log(e.getMessage());
			System.exit(0);
		}
		
		System.out.println("--------- ALL TRANSACTIONS ---------");
		for(Transaction t : trxs) {
			System.out.println(t.serialize());
		}
		System.out.println();
		
		validator = new TransactionValidator();
		try{
			validator.add( trxs );
		}
		catch(TransactionException e) {
			logger.log(e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
		validator.validate();
		
		List<Transaction> validTransactions = validator.getValidTransactions();//BIEN
		List<Transaction> invalidTransactions = validator.getInvalidTransactions();
		
		System.out.println("--------- VALID TRANSACTIONS ---------");
		for(Transaction t : validTransactions) {
			System.out.println(t.serialize());
		}
		System.out.println();


		new ValidTransactionWriter( trxFileName ).save( validTransactions );
		new InvalidTransactionWriter( trxFileName ).save( invalidTransactions );
		System.out.println("--------- INVALID TRANSACTIONS ---------");
		showInvalidTransactions( invalidTransactions );
	}

	public List<Transaction> getInvalidTransactions() {
		return validator.getInvalidTransactions();
	}
	
	
	private void showInvalidTransactions(List<Transaction> invalidTrxs) {
		for(Transaction t: invalidTrxs ) {
			System.out.println( t.serialize() );
			for(String error: t.getFaults() ) {
				System.out.println( error );
			}
			System.out.println();
		}
	}

}
