package uo.mp.transaction.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import uo.mp.transaction.validator.exception.TransactionException;

public class ZipFileUtil {

	public void writeLines(String pathToFile, List<String> lines) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		try(BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(pathToFile))))){
			for(String line : lines) {
				writer.write(line);
				writer.newLine();//true significa que esrcibe a continuación de lo que ya había
			}
		}
		catch(FileNotFoundException e) {
			throw new TransactionException("FILE NOT FOUND, MAY BE CORRUPTED");
		}
	}
	
	public List<String> readLines(String pathToFile) throws FileNotFoundException, IOException{
		List<String> res = new ArrayList<>();
		try(BufferedReader reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(pathToFile))))) {
			while(reader.ready()) {
				String line = reader.readLine();
				res.add(line);
			}
		}
		catch(IOException e) {
			throw new RuntimeException("Error en lectura de datos");
		}
		return res;
	}
}
