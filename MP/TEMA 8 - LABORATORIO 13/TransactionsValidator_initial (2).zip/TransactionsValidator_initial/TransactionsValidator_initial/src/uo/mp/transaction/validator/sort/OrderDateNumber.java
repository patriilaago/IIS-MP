package uo.mp.transaction.validator.sort;

import java.util.Comparator;

import uo.mp.transaction.model.Transaction;

public class OrderDateNumber implements Comparator<Transaction>{

	@Override
	public int compare(Transaction o1, Transaction o2) {
		// TODO Auto-generated method stub
		if(o1.getDate().compareTo(o2.getDate())==0) {
			return o1.getNumber().compareTo(o2.getNumber());
		}
		else {
			return o1.getDate().compareTo(o2.getDate());
		}
	}

}
