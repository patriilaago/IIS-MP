package uo.mp.transaction.validator.parser;

import java.util.ArrayList;
import java.util.List;

import uo.mp.transaction.model.BankTransferTransaction;
import uo.mp.transaction.model.ClientType;
import uo.mp.transaction.model.CreditCardTransaction;
import uo.mp.transaction.model.Transaction;
import uo.mp.transaction.validator.exception.InvalidLineException;

public class TransactionParser {

	private final static int CREDITCARD_FIELDS = 7;
	private final static int CURRENTACCOUNT_FIELDS = 6;
	
	public List<Transaction> parse(List<String> lines) throws InvalidLineException {
		// TODO Auto-generated method stub
		List<Transaction> transactions = new ArrayList<>();
		for(String line: lines) {
			int index = lines.indexOf(line);
			if(line.isBlank()||line.isEmpty()||line.equals(null)) {
				throw new InvalidLineException(index, "NULL OR EMPTY LINE");
			}
			else {
				transactions.add(parseLine(line,index));
			}
		}
		return transactions;
	}

	private Transaction parseLine(String line, int index) throws InvalidLineException {
		// TODO Auto-generated method stub
		String[] parts = line.split(";");
		if(!parts[0].contentEquals("cc") && !parts[0].contentEquals("acc")) {
			throw new InvalidLineException(index, "INVALID KEYWORD");
		}
		else if(parts.length > CREDITCARD_FIELDS && parts.length < CURRENTACCOUNT_FIELDS) {
			throw new InvalidLineException(index, "INCORRECT NUMBER OF FIELDS");
		}
		else {
			if(parts[0].contentEquals("cc") && parts.length == CREDITCARD_FIELDS) {
				return parseCreditCard(parts, index);
			}
			if(parts[0].contentEquals("acc") && parts.length == CURRENTACCOUNT_FIELDS) {
				return parseBankTransfer(parts, index);
			}
		}
		return null;
	}

	private BankTransferTransaction parseBankTransfer(String[] parts, int index) throws InvalidLineException {
		// TODO Auto-generated method stub
		int INDEX_DATE = 1, NUMBER = 2, CLIENT = 3, AMOUNT = 4, DESCRIPTION = 5;

		String date = parseDate(parts[INDEX_DATE],index);
		String card_number = parts[NUMBER];
		String description = parts[DESCRIPTION];
		double amount;
		if(!parts[AMOUNT].matches("\\d+")) {
				throw new InvalidLineException(index, "INVALID NUMBER FORMAT");
		}
		else {
			amount = Double.parseDouble(parts[AMOUNT]);
		}
		ClientType type = convertToClient(parts[CLIENT],index);
		return new BankTransferTransaction(date, card_number, amount, description, type);
	}
	
	private CreditCardTransaction parseCreditCard(String[] parts, int index) throws InvalidLineException {
		// TODO Auto-generated method stub
		int INDEX_DATE = 1, NUMBER = 2, EXPIRATION = 3, MAX_AMOUNT = 4, AMOUNT = 5, DESCRIPTION = 6;
		String date = parseDate(parts[INDEX_DATE],index);
		String card_number = parts[NUMBER];
		double amount;
		if(!parts[AMOUNT].matches("\\d+")) {
			throw new InvalidLineException(index, "INVALID NUMBER FORMAT");
		}
		else {
			amount = Double.parseDouble(parts[AMOUNT]);
		}
		String expiration = parts[EXPIRATION];
		double max_amount;
		if(!parts[MAX_AMOUNT].matches("\\d+")) {
			throw new InvalidLineException(index, "INVALID NUMBER FORMAT");
		}
		else {
			max_amount = Double.parseDouble(parts[MAX_AMOUNT]);
		}
		String description = parts[DESCRIPTION];
		return new CreditCardTransaction(date, card_number, amount, description, expiration,max_amount);
	}
	
	private String parseDate(String date, int index) throws InvalidLineException {
		String[] fields = date.split("/");
		if(fields[0].length()!=4||fields[1].length()!=2||fields[2].length()!=2||fields.length!=3) {
			throw new InvalidLineException(index, "INVALID DATE FORMAT");
		}
		
		try {
	        int year = Integer.parseInt(fields[0]);
	        int month = Integer.parseInt(fields[1]);
	        int day = Integer.parseInt(fields[2]);
	        
	        // Verificar los límites de los valores
	        if (year < 2021 || month < 1 || month > 12 || day < 1 || day > 31) {
	            throw new InvalidLineException(index, "INVALID DATE FORMAT");
	        }
	    } catch (NumberFormatException e) {
	        throw new InvalidLineException(index, "INVALID DATE FORMAT");
	    }

	    // Si pasa todas las validaciones, devolvemos la fecha original
	    return date;
	}
	
	private ClientType convertToClient(String client, int index) throws InvalidLineException {
		switch (client) {
		case "N":
			return ClientType.NORMAL;
		case "P":
			return ClientType.PREMIUM;
			default:
				throw new InvalidLineException(index, "Error: cliente no válido");
		}
	}
}
