package uo.mp.transaction.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import uo.mp.transaction.validator.exception.TransactionException;

public abstract class Transaction {

	private String date;
	private String number;
	private double amount;
	private String description;
	
	private List<String> validationFaults = new ArrayList<>();

	public Transaction(String date, String number, double amount,
			String description) {
		super();
		this.setDate(date);
		this.setNumber(number);
		this.setAmount(amount);
		this.setDescription(description);
	}

	public void setDescription(String description) {
		// TODO Auto-generated method stub
		this.description = description;
	}

	public void setAmount(double amount) {
		// TODO Auto-generated method stub
		this.amount = amount;
	}

	public void setNumber(String number) {
		// TODO Auto-generated method stub
		this.number = number;
	}

	public void setDate(String date) {
		// TODO Auto-generated method stub
		this.date = date;
	}

	public abstract void validate() throws TransactionException;

	public abstract String serialize();

	public void addFault(String error) {
		validationFaults.add(error);
	}

	public String getNumber() {
		return number;
	}

	public double getAmount() {
		return amount;
	}

	public String getDescription() {
		return description;
	}

	public List<String> getFaults() {
		return new ArrayList<>(validationFaults);
	}

	public String getDate() {
		return date;
	}

	public boolean hasFaults() {
		return validationFaults.size() > 0;
	}

	@Override
	public int hashCode() {
		return Objects.hash(amount, date, description, number, validationFaults);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		return Double.doubleToLongBits(amount) == Double.doubleToLongBits(other.amount)
				&& Objects.equals(date, other.date) && Objects.equals(description, other.description)
				&& Objects.equals(number, other.number) && Objects.equals(validationFaults, other.validationFaults);
	}
}
