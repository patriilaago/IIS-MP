package uo.mp.battleship.board;

import java.util.Objects;

public class Coordinate {
		
	private int col;
	private int row;
	
	public Coordinate(int col, int row) {
		Coordinate coordinate = new Coordinate(col,row);
	}

	public int getCol() {
		return col;
	}

	public int getRow() {
		return row;
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append("Coordinate ");
		result.append("[ ");
		result.append("x = ");
		result.append(getCol());
		result.append(", ");
		result.append("y = ");
		result.append(getRow());
		result.append(" ]");
		return result.toString();
	}

	public String toUserString() {
		return null;
	}

	@Override
	public int hashCode() {
		return Objects.hash(col, row);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coordinate other = (Coordinate) obj;
		return col == other.col && row == other.row;
	}
}
