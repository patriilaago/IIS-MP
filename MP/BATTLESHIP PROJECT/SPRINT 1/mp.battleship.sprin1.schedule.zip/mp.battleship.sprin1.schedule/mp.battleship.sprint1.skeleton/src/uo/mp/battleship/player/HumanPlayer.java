package uo.mp.battleship.player;

import uo.mp.battleship.board.Board;
import uo.mp.battleship.board.Coordinate;
import uo.mp.util.check.ArgumentChecks;

public class HumanPlayer {

	public HumanPlayer(String name) {
		if(name==null) {
			
		}
		
	}


	public String getName() {
		return null;
	}

	public void setMyShips(Board board) {
		
	}

	public void setOpponentShips(Board board) {
		
	}

	public boolean shootAt(Coordinate position) {
		return false;
	}

	public Board getMyShips() {
		return null;
	}

	public Board getOpponentShips() {
		return null;
	}

	public boolean hasWon() {
		return false;
	}


	public Coordinate makeChoice() {
		return null;
		
	}
	
}
