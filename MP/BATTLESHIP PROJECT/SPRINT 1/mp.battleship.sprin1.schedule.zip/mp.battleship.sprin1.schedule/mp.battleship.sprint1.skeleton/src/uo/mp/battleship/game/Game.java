package uo.mp.battleship.game;

import uo.mp.battleship.player.ComputerPlayer;
import uo.mp.battleship.player.HumanPlayer;

public class Game {

	
	public Game(HumanPlayer leftPlayer, ComputerPlayer rightPlayer) {
	}
	
	public void setDebugMode ( boolean gameMode ) {
	}

	public void play() {
	}


}
