package uo.mp.battleship.board;

public class Board {

	public Board( ) {
	}

	public boolean shootAt(Coordinate position) {
		return false;
	}	
	
	public boolean isFleetSunk() {
		return true;
	}
	
	
	public int getSize() {
		return -1;
	}

	public char[][] getFullStatus() {
		return null;
	}

	public char[][] getMinimalStatus() {
		return null;
		
	}

}
