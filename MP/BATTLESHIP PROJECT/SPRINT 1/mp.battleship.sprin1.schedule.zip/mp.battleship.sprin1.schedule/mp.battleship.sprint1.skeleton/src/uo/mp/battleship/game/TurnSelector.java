package uo.mp.battleship.game;
/*
 * Package-protected class, only accessed by game class (in the same folder)
 */
class TurnSelector {

	TurnSelector() {
	}
	
	int next() {
		return -1;
	}
}

