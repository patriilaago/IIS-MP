package uo.mp.battleship.session;


import java.time.LocalDateTime;

import uo.mp.battleship.interaction.GameInteractor;
import uo.mp.battleship.interaction.GamePresenter;
import uo.mp.battleship.interaction.RandomGameInteractor;
import uo.mp.battleship.interaction.SessionInteractor;
import uo.mp.battleship.model.game.Game;
import uo.mp.battleship.model.player.Player;
import uo.mp.battleship.model.ranking.GameRanking;
import uo.mp.battleship.model.ranking.Score;

public class GameSession {

	private final static int FIRST = 1;
	private final static int SECOND = 2;
	private final static int THIRD = 3;
	private final static int EXIT = 0;
	private final static int INITIAL = -1;
	
	private SessionInteractor sessionInteractor;
	private GameInteractor gameInteractor;
	private GamePresenter gamePresenter;
	private GameRanking gameRanking;
	
	public void run() {
		String name = sessionInteractor.askUserName();
		Player human = new Player(name);
		Player computer = new Player("Computer");
		human.setInteractor(gameInteractor);
		int option = INITIAL;
		do {
			sessionInteractor.showMenu();
			option = sessionInteractor.askNextOption();
			switch (option){
				case FIRST:
					GameLevel level = sessionInteractor.askGameLevel();
					boolean debugMode = sessionInteractor.askDebugMode();
					RandomGameInteractor randomGameInteractor = new RandomGameInteractor(level.getSize());
					computer.setInteractor(randomGameInteractor);
					Game game = new Game(human, computer);
					game.setPresenter(gamePresenter);
					game.setDebugMode(debugMode);
					LocalDateTime start = LocalDateTime.now();
					game.play();
					LocalDateTime end = LocalDateTime.now();
					boolean save = sessionInteractor.doYouWantToRegisterYourScore();
					if(save) {
						Score score = new Score(name, level, start, end);
						gameRanking.append(score);
					}
					break;
				case SECOND:
					sessionInteractor.showRanking(gameRanking.getRanking());
					break;
				case THIRD:
					sessionInteractor.showPersonalRanking(gameRanking.getRankingFor(name));
					break;
				case EXIT:
					sessionInteractor.sayGoodbye();
					System.exit(EXIT);
					break;
				default:
					throw new IllegalArgumentException(String.format("The number (%d) is not a valid option", option));
			}
		}while(option!=EXIT);
	}
	
	public void setSessionInteractor(SessionInteractor interactor) {
		this.sessionInteractor=interactor;
	}
	
	public void setGameInteractor(GameInteractor interactor) {
		this.gameInteractor=interactor;
	}

	public void setGamePresenter(GamePresenter presenter) {
		this.gamePresenter=presenter;
	}
	
	public void setGameRanking(GameRanking ranking) {
		this.gameRanking=ranking;
	}
}
