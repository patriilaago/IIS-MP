package uo.mp.battleship.console;

import uo.mp.battleship.interaction.GamePresenter;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.battleship.model.player.Player;
import uo.mp.util.check.ArgumentChecks;
import uo.mp.util.console.Console;

public class ConsoleGamePresenter implements GamePresenter{

	/**
	 * Prints the whole game in the console
	 */
	public void showGameStatus(Board left, Board right, boolean debugMode) {
		ArgumentChecks.isNotNull(left, "Cannot instanciate the left player because the board is null");
		ArgumentChecks.isNotNull(right, "Cannot instanciate the right player because the board is null");
		ArgumentChecks.isNotNull(debugMode, "Cannot start the game because the game mode is null");
		
		char[][] boardLeft = left.getFullStatus();
		char[][] boardRight;
		System.out.println("         MY SHIPS                    OPPONENT'S SHIPS"); //Print titles
		System.out.println("   A B C D E F G H I J		   A B C D E F G H I J");//print letters

		if(debugMode){
			boardRight = right.getFullStatus();
		}
		else{
			boardRight = right.getMinimalStatus();
		}

		for(int row=0;row<left.getSize();row++) {//in each line
			System.out.print(row+1);
			if(row!=9)
				System.out.print("  ");
			if (row==9)
				System.out.print(" ");
			for(int j=0;j<left.getSize();j++) {
				System.out.print(boardLeft[row][j]+"|");//row of user board
			}
			System.out.print("		");
			System.out.print(row+1);
			if(row!=9)
				System.out.print("  ");
			if (row==9)
				System.out.print(" ");
			for(int column=0;column<left.getSize();column++) {
				System.out.print(boardRight[row][column]+"|");
			}
			System.out.println();
		}
	}	

	/*
	 * Expected message
	 * 		The game is over!!
	 */
	public void showGameOver() {
		System.out.println("The game is over!!");
	}
	
	/*
	 * Expected message
	 * 		Shoot at user-friendly
	 */
	public void showShootingAt(Coordinate position) {
		ArgumentChecks.isNotNull(position, "The position where you want to shoot at cannot be null");
		System.out.println("Shooting at " + position.toUserString() + ".");
	}

	/*
	 * Expected message
	 * 		Depending on the shot result:
	 * 		MISS, HIT!!. Continue, HIT AND SUNK!!. Continue (from sprint 2 on)
	 */
	public void showShotMessage(Damage damage) {
		ArgumentChecks.isNotNull(damage, "The damage cannot be null");
		if (damage==Damage.NO_DAMAGE) {
            System.out.println("MISS");
        } 
		else if(damage==Damage.SEVERE_DAMAGE){
            System.out.println("HIT!! Continue");
        }
		else {
			System.out.println("HIT AND SUNK!! Continue");
		}
	}

	/*
	 * Expected message 
	 * 		The winner is ... winner name
	 */
	@Override
	public void showWinner(Player theWinner) {
		ArgumentChecks.isTrue(theWinner!=null , "The winner of the game cannot be null");
		System.out.println("The winner is ..." + theWinner.getName());
		
	}

	/*
	 * Expected message
	 * 		Now the turn is for the player player name
	 */
	@Override
	public void showTurn(Player player) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(player!=null, "The name player which has his turn now of the game cannot be null, blank or empty");
		System.out.println("It's " + player.getName() + "'s turn.");
	}

	@Override
	public void showErrorMessage(String message) {
		// TODO Auto-generated method stub
		Console.printError("ERROR: ");
		Console.printError( message );
		Console.printError("Please, try it again.");
	}
}
