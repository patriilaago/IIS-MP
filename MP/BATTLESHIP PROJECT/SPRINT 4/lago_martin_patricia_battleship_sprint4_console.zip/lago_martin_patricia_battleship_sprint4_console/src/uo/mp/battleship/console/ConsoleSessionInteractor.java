package uo.mp.battleship.console;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import uo.mp.battleship.interaction.SessionInteractor;
import uo.mp.battleship.menu.Menu;
import uo.mp.battleship.model.ranking.Score;
import uo.mp.battleship.session.GameLevel;
import uo.mp.util.check.ArgumentChecks;
import uo.mp.util.console.Console;

public class ConsoleSessionInteractor implements SessionInteractor {

	private final static char SEA = 's';
	private final static char OCEAN = 'o';
	private final static char PLANET = 'p';
	private final static char YES = 'y';
	private final static char NO = 'n';
	
	private Menu menu = new Menu( new String[]{
			"Play a new game",
			"Show my results",
			"Show all results"
		});
	
	
	@Override
	public GameLevel askGameLevel() {
		Scanner scanner = new Scanner(System.in);
        char option;
        do {
            System.out.print("Level (s)ea, (o)cean, (p)lanet? ");
            option = scanner.nextLine().trim().toLowerCase().charAt(0);
            switch(option) {
                case SEA:
                    return GameLevel.SEA;
                case OCEAN:
                    return GameLevel.OCEAN;    
                case PLANET:
                    return GameLevel.PLANET;    
                default:
                    System.out.println("Invalid option. Please enter 's' for sea, 'o' for ocean, or 'p' for planet.");
            }
        } while (option != SEA && option != OCEAN && option != PLANET);
        return null;
    }
	
	@Override
	public String askUserName() {
		Scanner scanner = new Scanner(System.in);
        String playerName;
        do {
            System.out.println("Player name? ");
            playerName = scanner.nextLine().trim(); // Eliminar espacios en blanco al principio y al final
            if (playerName.isEmpty()) {
                System.out.println("The name cannot be empty. Please try again.");
            }
        } while (playerName.isEmpty());
        return playerName;
    }

	@Override
	public int askNextOption() {
		return menu.askOption();
	}

	@Override
	public boolean askDebugMode() {
		Scanner scanner = new Scanner(System.in);
        char c;
        do {
            System.out.print("Do you want to play in debug mode (y)es, (n)o? ");
            c = scanner.nextLine().trim().toLowerCase().charAt(0);
            if (c != YES && c != NO) {
                System.out.println("Invalid input. Please enter 'y' for yes or 'n' for no.");
            }
        } while (c != YES && c != NO);
        return c == YES;
    }

	@Override
	public boolean doYouWantToRegisterYourScore() {
		Scanner scanner = new Scanner(System.in);
        char c;
        do {
        	System.out.print("Do you want to store your score (y)es, (n)o ? ");
			c = String.valueOf( Console.readChar() ).toLowerCase().charAt( 0 );
			if (c != YES && c != NO) {
                System.out.println("Invalid input. Please enter 'y' for yes or 'n' for no.");
            }
        } while (c != YES && c != NO);
        return c == YES;
	}

	@Override
	public void showRanking(List<Score> ranking) {
		ArgumentChecks.isNotNull( ranking );
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd\tHH:mm:ss     ");
		Console.println("User name\t.Date\t\t.Hour\t\t.Level\t.Time");
		for (Score rl: ranking) {		
			LocalDateTime dateTime = rl.getEndTime();
			String formattedDateTime = dateTime.format(formatter);
			String s = String.format(
					"%-10.10s\t%-20.20s\t%-6.6s\t%4d",
						rl.getUserName(),
						formattedDateTime,
						rl.getLevel(),
						rl.getTime()
					);
			Console.println( s );
		}		
	}

	@Override
	public void showPersonalRanking(List<Score> ranking) {
		ArgumentChecks.isNotNull( ranking );
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd\tHH:mm:ss     ");
		Console.println("Date\t\t.Hour\t\t.Level\t.Time");

		for (Score rl: ranking) {
			LocalDateTime dateTime = rl.getEndTime();
			String formattedDateTime = dateTime.format(formatter);
			String s = String.format(
					"%-20.20s\t%-6.6s\t%4d",
						formattedDateTime,
						rl.getLevel(),
						rl.getTime()
					);
			Console.println( s );
		}		
	}

	@Override
	public void showErrorMessage(String message) {
		Console.printError("ERROR: ");
		Console.printError( message );
		Console.printError("Please, try it again.");		
	}

	@Override
	public void showFatalErrorMessage(String message) {
		Console.printError("FATAL ERROR:");
		Console.printError( message );
		Console.printError("The program must stop execution.");		
	}

	@Override
	public void sayGoodbye() {
		// TO DO
		System.out.println("Thank you for playing battleship. Bye bye!");
	}

	@Override
	public void showMenu() {
		menu.showOptions();		
	}
}
