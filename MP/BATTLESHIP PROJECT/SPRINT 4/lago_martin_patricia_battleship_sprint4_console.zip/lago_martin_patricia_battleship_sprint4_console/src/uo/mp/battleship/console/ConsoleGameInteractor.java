package uo.mp.battleship.console;

import uo.mp.battleship.interaction.GameInteractor;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.util.console.Console;

public class ConsoleGameInteractor implements GameInteractor{

	@Override
	public Coordinate getTarget() {
		// TODO Auto-generated method stub
		return generateCoordinates();
	}
	
	public Coordinate generateCoordinates() {
		Console.print("Col (letter): ");

		char caracter = Console.readChar();
		caracter = (caracter + " ").toUpperCase().charAt(0);

		int x = caracter - 'A';

		Console.print("Row (number): ");

		int y = Console.readInt() - 1;

		return new Coordinate(x, y);
	}
}
