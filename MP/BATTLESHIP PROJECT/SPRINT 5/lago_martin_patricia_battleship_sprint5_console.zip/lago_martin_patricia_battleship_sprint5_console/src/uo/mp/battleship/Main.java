package uo.mp.battleship;

import uo.mp.battleship.console.ConsoleGameInteractor;
import uo.mp.battleship.console.ConsoleGamePresenter;
import uo.mp.battleship.console.ConsoleSessionInteractor;
import uo.mp.battleship.model.ranking.FileLogger;
import uo.mp.battleship.session.GameSession;

public class Main {
	
	private static final String RANKING_FILE = "battleship.rnk";
	private static final String LOG_FILE = "battleship.log";
	private FileLogger logger;
	
	private GameSession session = new GameSession(logger);

	public static void main(String[] args) {
		new Main()
			.configure()
			.run();
	}

	private Main configure() {
		session.setSessionInteractor( new ConsoleSessionInteractor() );
		session.setGameInteractor( new ConsoleGameInteractor() );
		session.setGamePresenter( new ConsoleGamePresenter() );
		session.setLoggerFile( LOG_FILE );
		session.setGameRankingFile( RANKING_FILE );	

		return this;
	}

	private void run() {
		session.run();
	}

}
