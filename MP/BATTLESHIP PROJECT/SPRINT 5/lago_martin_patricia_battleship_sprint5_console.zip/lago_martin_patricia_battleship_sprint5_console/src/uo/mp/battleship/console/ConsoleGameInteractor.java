package uo.mp.battleship.console;

import uo.mp.battleship.interaction.GameInteractor;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.util.console.Console;

public class ConsoleGameInteractor implements GameInteractor{

	@Override
	public Coordinate getTarget() {
		// TODO Auto-generated method stub
		return generateCoordinates();
	}
	
	public Coordinate generateCoordinates() {
		char caracter = ' ';
		while(!Character.isLetter(caracter)) {
			Console.print("Col (letter): ");
			caracter = Console.readChar();
			caracter = (caracter + " ").toUpperCase().charAt(0);
		}
		int x = caracter - 'A';

		int y = Integer.MIN_VALUE;
		while(true) {
			Console.print("Row (number): ");
			try {
				y = Console.readInt() - 1;
			}
			catch(NumberFormatException e) {
				y = Integer.MIN_VALUE;
			}
			if(y!=Integer.MIN_VALUE) {
				break;
			}
		}

		return new Coordinate(x, y);
	}
}
