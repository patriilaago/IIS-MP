package uo.mp.battleship.model.board;

import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.battleship.model.board.squares.Ship;
import uo.mp.battleship.model.board.squares.Target;
import uo.mp.battleship.model.board.squares.Water;
import uo.mp.util.check.ArgumentChecks;

public class Square {

	private Target content;
	private boolean isShot = false;
	
	/**
	 * 
	 * @return the content of the square, that can be a ship or water
	 */
	public Target getContent() {
		return content;
	}
	
	/**
	 * Sets the object referred by this square to be the one passed as argument. It could be a Ship or Water object
	 * @param content Water or ship that will be the content of the Square
	 * @return the square it self
	 */
	public Square setContent(Target content) {
		ArgumentChecks.isNotNull(content, "The content of the square cannot be null");
		this.content=content;
		return this;
	}
	
	/**
	 * It marks this square as shot and propagates the shot to the Ship or Water referred by this square
	 * @return enum Damage depending on the damage caused by the shot
	 */
	public Damage shootAt() {
        isShot = true;
		return content.shootAt();
	}
	
	/**
	 * 
	 * @return true if the square has been shot, false otherwise
	 */
	public boolean isShot() {
		return this.isShot;
	}
	
	/**
	 * 
	 * @return character corresponding to the content: a Ship or Water (shot or not)
	 */
	public char toChar() {
		return this.content.toChar();
	}
	
	/**
	 * 
	 * @return character corresponding to the content: a Ship or Water (shot or not)
	 */
	public char toFiredChar() {
		return this.content.toFiredChar();
	}
	
	/**
	 * 
	 * @return true if the content of this Square is set to a Ship or a Water object, false otherwise
	 */
    public boolean hasContent() {
        if(getContent() instanceof Water || getContent() instanceof Ship) {
        	return true;
        }
        return false;
    }
}
