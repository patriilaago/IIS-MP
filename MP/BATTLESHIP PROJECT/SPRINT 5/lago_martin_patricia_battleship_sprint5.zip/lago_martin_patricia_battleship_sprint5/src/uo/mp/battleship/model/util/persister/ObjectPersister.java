package uo.mp.battleship.model.util.persister;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import uo.mp.battleship.model.ranking.Score;

public class ObjectPersister {
	
	public static Object load(String arg) throws IOException, ClassNotFoundException {
		ArrayList<Score> scores = new ArrayList<>();
		Object ob = null;
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(arg));) {
//			 Method for deserialization of object	
			ob = in.readObject();
		} 
		return ob;
	}

	public static void save(String arg, Serializable object) throws FileNotFoundException, IOException {
		//Saving of object in a file
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(arg,true)); //
         
        // Method for serialization of object
        out.writeObject(object);
         
        out.close();
	}

}