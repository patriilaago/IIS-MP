package uo.mp.battleship.model.game;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.squares.Damage;

import java.time.LocalDateTime;

import uo.mp.battleship.exception.InvalidCoordinateException;
import uo.mp.battleship.interaction.GamePresenter;
import uo.mp.battleship.model.player.Player;
import uo.mp.battleship.session.GameLevel;
import uo.mp.util.check.ArgumentChecks;

public class Game {

	private Player humanPlayer;
	private Player computerPlayer;
	private TurnSelector turnSelector;
	private GamePresenter presenter;
	private Board computerBoard;
	private Board humanBoard;
	private boolean debugMode = true;
	private LocalDateTime startTime;
	private LocalDateTime endTime;
	private GameLevel level;
	
	/**
	 * Creates a new game with two players (a human and a computer)
	 * @param leftPlayer leftPlayer that will play, in this case yourself
	 * @param rightPlayer rightPlayer that will play, in this case a computer
	 */
	public Game(Player leftPlayer, Player rightPlayer, GameLevel level) {
		this.humanPlayer = leftPlayer;
		this.computerPlayer = rightPlayer;
		this.turnSelector = new TurnSelector(leftPlayer, rightPlayer);
		this.setLevel(level);
		humanBoard = new Board(level.getSize());
		computerBoard = new Board(level.getSize());
		this.humanPlayer.setMyShips(humanBoard);
		this.humanPlayer.setOpponentShips(computerBoard);
		this.computerPlayer.setMyShips(computerBoard);
		this.computerPlayer.setOpponentShips(humanBoard);
	}
	
	/**
	 * 
	 * @param presenter communicates with the player (output)
	 */
	public void setPresenter(GamePresenter presenter) {
		ArgumentChecks.isNotNull(presenter,"The game presenter cannot be null");
		this.presenter = presenter;
	}

	/**
	 * 
	 * @param gameMode in which you want to play, normal one or debug one
	 */
	public void setDebugMode ( boolean gameMode ) {
		ArgumentChecks.isNotNull(gameMode, "The game mode cannot be null");
		this.debugMode = gameMode;
	}
	
	/**
	 * Makes the whole user interaction. It manages the main loop, where 
	 * players alternate turns to shoot while there is no winner.
	 */
	public void play() {
		while(!humanPlayer.hasWon() && !computerPlayer.hasWon()) {
			if(turnSelector.getTurn() == humanPlayer) {
				presenter.showGameStatus(humanPlayer.getMyShips(), humanPlayer.getOpponentShips(), this.debugMode);
				presenter.showTurn(humanPlayer);
				Coordinate choice = humanPlayer.makeChoice();
				choice.setLevel(level);
				Damage damage = Damage.NO_DAMAGE;
				try {
					damage = humanPlayer.getOpponentShips().shootAt(choice);
					presenter.showShootingAt(choice);
				} catch (InvalidCoordinateException e) {
					// TODO Auto-generated catch block
					presenter.showErrorMessage(e.getMessage());
				}
				presenter.showShotMessage(damage);
				if(damage != Damage.NO_DAMAGE) {
					turnSelector.repeat();
				}
				else {
					turnSelector.next();
				}
			}
			else {
				presenter.showGameStatus(computerPlayer.getMyShips(), computerPlayer.getOpponentShips(), this.debugMode);
				presenter.showTurn(computerPlayer);
				Coordinate choice = computerPlayer.makeChoice();
				choice.setLevel(level);				
				Damage damage = Damage.NO_DAMAGE;
				try {
					damage = computerPlayer.getOpponentShips().shootAt(choice);
					presenter.showShootingAt(choice);
				} catch (InvalidCoordinateException e) {
					// TODO Auto-generated catch block
					presenter.showErrorMessage(e.getMessage());
				}
				presenter.showShotMessage(damage);
				if(damage != Damage.NO_DAMAGE) {
					turnSelector.repeat();
				}
				else {
					turnSelector.next();
				}
			}
		}
		if(humanPlayer.hasWon()) {
			presenter.showWinner(humanPlayer);
		}
		else if(computerPlayer.hasWon()){
			presenter.showWinner(computerPlayer);
		}
	}
	
	public LocalDateTime getInitialTime() {
		return startTime;
	}
	
	public LocalDateTime getEndTime() {
		return endTime;
	}
	
	public GameLevel getLevel() {
		return level;
	}

	public void setLevel(GameLevel level) {
		this.level = level;
	}
}
