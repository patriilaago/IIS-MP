package uo.mp.battleship.model.board;

import java.util.List;

import uo.mp.battleship.model.board.squares.Ship;
import uo.mp.battleship.model.board.squares.Water;

public class BoardBuilder {
	static int[][] build() {
		return new int[][] {	
				{ 1, 0, 1, 0, 1, 0, 1, 0, 0, 0 }, 
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, 
				{ 2, 2, 0, 2, 2, 0, 2, 2, 0, 0 },
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
				{ 3, 3, 3, 0, 3, 3, 3, 0, 0, 0},
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
				{ 0, 0, 0, 0, 4, 4, 4, 4, 0, 0},
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
				{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
		 };
	}
	
	static Square[][] build2(int size, List<Ship> fleet){
		Square[][] matrix = new Square[size][size];
		for(int row = 0 ; row < matrix.length ; row++) {
			for(int column = 0 ; column < matrix[0].length ; column++) {
				matrix[row][column] = new Square().setContent(new Water());
			}
		}
		
		matrix[0][0] = new Square().setContent(new Ship(1));
		matrix[0][2] = new Square().setContent(new Ship(1));
		matrix[0][4] = new Square().setContent(new Ship(1));
		matrix[0][6] = new Square().setContent(new Ship(1));
		
		Ship size2_1 = new Ship(2);
		matrix[2][0] = new Square().setContent(size2_1);
		matrix[2][1] = new Square().setContent(size2_1);
		
		Ship size2_2 = new Ship(2);
		matrix[2][3] = new Square().setContent(size2_2);
		matrix[2][4] = new Square().setContent(size2_2);
		
		Ship size2_3 = new Ship(2);
		matrix[2][6] = new Square().setContent(size2_3);
		matrix[2][7] = new Square().setContent(size2_3);
		
		Ship size3_1 = new Ship(3);
		matrix[4][0] = new Square().setContent(size3_1);
		matrix[4][1] = new Square().setContent(size3_1);
		matrix[4][2] = new Square().setContent(size3_1);
		
		Ship size3_2 = new Ship(3);
		matrix[4][4] = new Square().setContent(size3_2);
		matrix[4][5] = new Square().setContent(size3_2);
		matrix[4][6] = new Square().setContent(size3_2);
		
		Ship size4 = new Ship(4);
		matrix[6][4] = new Square().setContent(size4);
		matrix[6][5] = new Square().setContent(size4);
		matrix[6][6] = new Square().setContent(size4);
		matrix[6][7] = new Square().setContent(size4);
		
		return matrix;
	}
}
