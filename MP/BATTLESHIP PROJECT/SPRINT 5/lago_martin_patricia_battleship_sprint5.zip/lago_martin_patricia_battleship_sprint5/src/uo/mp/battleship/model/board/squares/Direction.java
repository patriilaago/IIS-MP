package uo.mp.battleship.model.board.squares;

public enum Direction {
	NORTH, SOUTH, EAST, WEST
}
