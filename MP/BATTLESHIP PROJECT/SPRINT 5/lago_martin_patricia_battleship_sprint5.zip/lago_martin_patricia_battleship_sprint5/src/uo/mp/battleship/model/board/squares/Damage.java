package uo.mp.battleship.model.board.squares;

public enum Damage {
	NO_DAMAGE,SEVERE_DAMAGE,MASSIVE_DAMAGE
}
