package uo.mp.battleship.interaction;

import java.util.ArrayList;
import java.util.Random;

import uo.mp.battleship.model.board.Coordinate;

public class RandomGameInteractor implements GameInteractor{

	private ArrayList<Coordinate> alreadyFired = new ArrayList<Coordinate>();
	private int size;
	
	public RandomGameInteractor(int size) {
		this.size = size;
	}
	
	@Override
	public Coordinate getTarget() {
		Random random = new Random();
		int row = random.nextInt(size);
		int column = random.nextInt(size);
		Coordinate coordinate = new Coordinate(column, row);
		while (alreadyFired.contains(coordinate)) {

			row = random.nextInt(size);
			column = random.nextInt(size);
			coordinate = new Coordinate(column, row);

		}
		alreadyFired.add(coordinate);
		return coordinate;
	}
}
