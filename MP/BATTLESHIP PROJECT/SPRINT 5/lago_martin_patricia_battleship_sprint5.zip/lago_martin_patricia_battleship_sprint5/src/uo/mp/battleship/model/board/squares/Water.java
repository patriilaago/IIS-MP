package uo.mp.battleship.model.board.squares;

public class Water implements Target{
	
	private static final char MISS = '\u00F8';
	private static final char WATER = ' ';
	
	/**
	 * Always returns NO_DAMAGE because it is never a ship
	 */
	public Damage shootAt() {
		return Damage.NO_DAMAGE;
	}
	
	/**
	 * It returns the character associated with a Water cell
	 */
    public char toChar() {
        return WATER;
    }
    
    /**
     * Returns the character associated with a missed shot
     */
    public char toFiredChar() {
        return MISS; 
    }
}
