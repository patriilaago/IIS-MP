package uo.mp.battleship.model.board.squares;

import uo.mp.util.check.ArgumentChecks;

public class Ship implements Target{
	
	private int shipSize;
    private int hitCount;
    private final static int MINIMUM_SHIP_SIZE = 0;
	private static final char BATTLESHIP = 'B';
	private static final char CRUISE = 'C';
	private static final char DESTROYER = 'D';
	private static final char SUBMARINE = 'S';
	private static final char HIT = '*';
	private static final char SUNK = '#';
	private static final char WATER = ' ';
    
    /**
     * Creates a new ship with a size that is passed as a parameter
     * @param shipSize
     */
    public Ship(int shipSize) {
        ArgumentChecks.isTrue(shipSize>MINIMUM_SHIP_SIZE, "The size of the ");
    	this.shipSize = shipSize;
        this.hitCount = MINIMUM_SHIP_SIZE;
    }

    /**
     * When we are hit by an opponent's shot,it returns the damage caused.
     */
    public Damage shootAt() {
    	hitCount++;
        if (isSunk()) {
        	return Damage.MASSIVE_DAMAGE;  
        }
        else if (hitCount<shipSize){
        	return Damage.SEVERE_DAMAGE; 
        }
        else {
        	return Damage.NO_DAMAGE; 
        }
    }

    /**
     * 
     * @return size of the ship
     */
    public int size() {
        return shipSize;
    }

    /**
     * Returns the character corresponding to the ship
     */
    public char toChar() {
        char theChar = WATER;
    	switch(shipSize) {
        case 1:
        	theChar = SUBMARINE;
        	break;
    	case 2:
    		theChar = DESTROYER;
    		break;
    	case 3:
    		theChar = CRUISE;
    		break;
    	case 4:
    		theChar = BATTLESHIP;
    		break;
    	}
    	return theChar;
    }

    /**
     * Returns the character corresponding to hit or hit and sunk.
     */
    public char toFiredChar() {
       if(isSunk()) {
    	   return SUNK;
       }
       else {
    	   return HIT;
       }
   }

    /**
     * Checks if the ship is sunk
     * @return true in case the ship has sunk, false otherwise
     */
   public boolean isSunk() {
       return this.hitCount == this.shipSize;
   }
}
