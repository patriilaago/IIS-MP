package uo.mp.battleship.model.board;

import uo.mp.battleship.exception.InvalidCoordinateException;
import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.battleship.model.board.squares.Ship;
import uo.mp.util.check.ArgumentChecks;

public class Board {
	
	private Square[][]board;
	private static final char WATER = ' ';
	private final static int ZERO = 0;

	/**
	 * Instantiates a new board with a size equal to the one passed as a parameter
	 * @param size of the board
	 */
	public Board(int size){
		this.board = new Square[size][size];
		this.board = BoardBuilder.build2(size, null);
	}
	
	/**
	 * Instantiates a new board equal to the one passed as a parameter
	 * @param arg board for the copy
	 */
	public Board(Square[][] arg) {
		Square[][] grid = new Square[arg.length][arg[0].length];
		
		for (int row = 0; row < arg.length; row++) {
			for (int column = 0; column < arg[0].length; column++) {
				grid[row][column]=arg[row][column];
			}
		}
	}
	
	/**
	 * Records a shoot at the coordinates it receives. In case there is a ship in 
	 * those coordinates(in any state),it returns true. 
	 * 
	 * @param position coordinate were the user is going to make its shoot
	 * @return
	 * @throws InvalidCoordinateException 
	 */
	public Damage shootAt(Coordinate position)throws InvalidCoordinateException {
		ArgumentChecks.isNotNull(position, "The coordinate you want to shoot at cannot be null");
		//INAVLID COORDINATE EXCEPTION
		int row=position.getRow();
		int column=position.getCol();
		if(column>board.length || row>board.length || column<ZERO || row<ZERO) {
			throw new InvalidCoordinateException(position);
		}
		return this.board[row][column].shootAt();
	}
	
	/**
	 * Checks whether the ships from the board have been sunk or not
	 * 
	 * @return true in case all the ships have been sunk, false otherwise
	 */
	public boolean isFleetSunk() {
		for(int row = 0 ; row < board.length ; row++) {
			for(int column = 0 ; column < board[0].length ; column++) {
				if(board[row][column].getContent() instanceof Ship) {
					Ship ship = (Ship) board[row][column].getContent();
					if(!ship.isSunk()) {
						return false;
					}
				}
			}
		}
		return true;
	}
	
	/**
	 * 
	 * @return size of the game's board
	 */
	public int getSize() {
		return this.board.length;
	}

	/**
	 * 
	 * @return  2D array of characters representing the state of the board. A character at (x, y) 
	 * coordinates represents the state of this square
	 */
	public char[][] getFullStatus() {
		char[][] status = new char[board.length][board[0].length];
		for (int row = 0; row < board.length; row++) {
			for (int column = 0; column < board[0].length; column++) {
				if(board[row][column].isShot()==true) {
					status[row][column] = this.board[row][column].getContent().toFiredChar();
				}
				else {
					status[row][column] = this.board[row][column].getContent().toChar();
				}
			}
		}
		return status;
	}

	/**
	 * 
	 * @return a 2D array of characters. However, it just returns the actual value 
	 * of those squares in the board that have already been shot. For those not guessed, it returns a 
	 * blank character
	 */
	public char[][] getMinimalStatus() {
		char[][] status = new char[board.length][board[0].length];
		for(int row = 0 ; row < board.length ; row++) {
			for(int column = 0 ; column < board[0].length ; column++) {
				if(board[row][column].isShot()==true) {
					status[row][column]=this.board[row][column].toFiredChar();
				}
				else {
					status[row][column]=WATER;
				}
			}
		}
		return status;
	}
	
	/**
	 * 
	 * @return copy of the inner array of integers
	 */
	public Square[][] getInnerArray(){
		Square[][] clone_board = board.clone();
		return clone_board;
	}
}
