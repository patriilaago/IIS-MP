package uo.mp.battleship.model.game;
/*
 * Package-protected class, only accessed by game class (in the same folder)
 */

import java.util.Random;

import uo.mp.battleship.model.player.Player;
import uo.mp.util.check.ArgumentChecks;

class TurnSelector {

	private Player humanPlayer;
	private Player computerPlayer;
	private Player currentPlayer;
	
	/**
	 * Creates a new Turn Selector, with a human player and a computer player that will start in a random way
	 * @param user player, in this case yourself
	 * @param computer player, in this case the computer
	 */
	TurnSelector(Player user, Player computer) {
		this.humanPlayer = user;
		this.computerPlayer = computer;//First turn is for the user
		this.currentPlayer = user;
		Random random = new Random();
		int value = random.nextInt(2);
		if(value == 0) {
			currentPlayer = humanPlayer;
		}
		else {
			currentPlayer = computerPlayer;
		}
	}
	
	/**
	 * 
	 * @return the turn for the player that has his turn to play
	 */
	public Player getTurn() {
		return currentPlayer;
	}
	
	/**
	 * Returns alternating human and computer (human for the user's turn and computer for computer's turn).
	 * 
	 * @return the turn for the next player, which can be the user or the computer
	 */
	Player next() {
		if(currentPlayer == computerPlayer) {
			currentPlayer = humanPlayer;
		}
		else {
			currentPlayer = computerPlayer;
		}
		return currentPlayer;
	}
	
	/**
	 * 
	 * @return the current player that has played before
	 */
	Player repeat() {
		return currentPlayer;
	}
	
	/**
	 * Sets the turn for a player
	 * @param currentPlayer that will play now
	 */
	public void setTurn(Player currentPlayer) {
		ArgumentChecks.isNotNull(currentPlayer, "The current player cannot be null");
		this.currentPlayer=currentPlayer;
	}
}

