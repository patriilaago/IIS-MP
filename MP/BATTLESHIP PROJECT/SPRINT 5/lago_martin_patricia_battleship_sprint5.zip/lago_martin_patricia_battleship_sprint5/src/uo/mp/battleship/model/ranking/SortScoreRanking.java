package uo.mp.battleship.model.ranking;

import java.util.Comparator;

public class SortScoreRanking implements Comparator<Score>{

	@Override
	public int compare(Score o1, Score o2) {
		if (o1.getLevel() == o2.getLevel()) {
			if (Long.compare(o1.getTime(), o2.getTime()) == 0) {
				return o1.getEndTime().compareTo(o2.getEndTime());
			} else {
				return Long.compare(o1.getTime(), o2.getTime());
			}
		} else {
			return o1.getLevel().compareTo(o2.getLevel());
		}
	}
}
