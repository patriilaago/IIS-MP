package uo.mp.battleship.model.ranking;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import uo.mp.battleship.model.util.persister.ObjectPersister;

public class GameRanking {
	

	private List<Score> scores = new ArrayList<>();
	private String fileName;
	private FileLogger logger;
	
	public GameRanking (String filename) throws ClassNotFoundException, IOException{
		this.fileName=filename;
		try{
			Score sc=(Score) ObjectPersister.load(filename);
//			scores = (List<Score>) ObjectPersister.load(filename);
			scores.add(sc);
//			Collections.sort(scores); //With comparable
//			Collections.sort(scores, new SortScoreRanking());
		}
		catch(FileNotFoundException e) {
			scores = new ArrayList<Score>();
		}
	}
	
	
	/**
	 * It adds the argument to the end of the list of scores.
	 * @param score
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public void append(Score score){
		scores.add(score);
		try {
			ObjectPersister.save(fileName,score);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			logger.log("File not found");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.log(e.getMessage());
			System.exit(0);
		}
		
	}
	
	/**
	 * 
	 * @return It returns a copy of the list of scores
	 */
	public List<Score> getRanking(){
		return new ArrayList<Score>(scores);
	}
	
	/**
	 * 
	 * @param userName 
	 * @return a list containing only those scores of the userName
	 */
	public List<Score> getRankingFor(String userName){
		List<Score> ranking = new ArrayList<>();
		for(Score score: scores) {
			if(score.getUserName().equals(userName)) {
				ranking.add(score);
			}
		}
		return ranking;
	}
}
