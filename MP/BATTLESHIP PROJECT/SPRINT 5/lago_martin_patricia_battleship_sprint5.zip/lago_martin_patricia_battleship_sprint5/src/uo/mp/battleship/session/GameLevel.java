package uo.mp.battleship.session;

public enum GameLevel {

	SEA("sea",10), OCEAN("ocean",15), PLANET("planet",20);

	private String level;
	private int size;
	
	GameLevel(String type, int size) {
		// TODO Auto-generated constructor stub
		setLevel(type);
		setSize(size);
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
}
