package uo.mp.battleship.model.player;

import uo.mp.battleship.exception.InvalidCoordinateException;
import uo.mp.battleship.interaction.GameInteractor;
import uo.mp.battleship.model.board.Board;
import uo.mp.battleship.model.board.Coordinate;
import uo.mp.battleship.model.board.squares.Damage;
import uo.mp.util.check.ArgumentChecks;

public class Player {
	
	private Board myShips;
    private Board opponentShips;
    private String name;
    private GameInteractor interactor;

    /**
     * Creates a new Player 
     * @param name for the player
     */
    public Player(String name){
    	setName(name);
    }
    
    /**
     * 
     * @return the Board with the ships corresponding to yourself
     */
	public Board getMyShips() {
		return myShips;
	}
	
	/**
	 * 
	 * @param board where you will instantiate your ships
	 */
	public void setMyShips(Board board) {
		ArgumentChecks.isNotNull(board, "Cannot instanciate your ships because the board is null");
		this.myShips=board;
	}

	/**
     * 
     * @return the Board with the ships corresponding to your opponent
     */
	public Board getOpponentShips() {
		return opponentShips;
	}

	/**
	 * 
	 * @param board where you will instantiate your opponent's ships
	 */
	public void setOpponentShips(Board board) {
		ArgumentChecks.isNotNull(board, "Cannot instanciate your opponent ships because the board is null");
		this.opponentShips=board;
	}
	
	public Damage shootAt(Coordinate position) throws InvalidCoordinateException {
		return opponentShips.shootAt(position);
	}
	
	/**
	 * Checks if the player has won the game
	 * @return true in case the player has won, false otherwise
	 */
	public boolean hasWon() {
		return opponentShips.isFleetSunk();
	}
	
	/**
	 * 
	 * @return name of the player
	 */
	public String getName() {
		return name;
	}

	/**
	 * 
	 * @param name corresponding for the one used for the player
	 */
	public void setName(String name) {
		ArgumentChecks.isTrue(name != null && !name.isBlank(), "The name of the player cannot be null or blank");
		this.name = name;
	}

	/**
	 * Used to communicate with the player (input)
	 * @param randomGameInteractor interactor that is going to be used in the game
	 */
	public void setInteractor(GameInteractor randomGameInteractor) {
		// TODO Auto-generated method stub
		ArgumentChecks.isNotNull(randomGameInteractor, "The game interactor cannot be null");
		this.interactor=randomGameInteractor;
	}
	
	/**
	 * Reads coordinates from keyboard and returns a Coordinate object.
	 * @return coordinate that you have chosen
	 */
	public Coordinate makeChoice() {
		return interactor.getTarget();
	}
}
