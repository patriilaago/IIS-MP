package uo.mp.battleship.model.board;

import java.util.Objects;

import uo.mp.battleship.exception.InvalidCoordinateException;
import uo.mp.battleship.model.board.squares.Direction;
import uo.mp.util.check.ArgumentChecks;


public class Coordinate {

	private int column;
	private int row;
	private int[] coordinate = new int[2];

	
	/**
	 * Instantiates a new Coordinate with a value for the column and another one for the row
	 * @param col column value for the board
	 * @param row row value for the board
	 */
	public Coordinate(int theCol, int theRow) {
		//ArgumentChecks.isTrue(theRow>=0&&theRow<10, "Invalid coordinate (row out of range)");
		//ArgumentChecks.isTrue(theCol>=0&&theCol<10, "Invalid coordinate (column out of range)");
		column = theCol;
		row = theRow;
		
		coordinate[0]=theCol;
		coordinate[1]= theRow;
	}
	

	/**
	 * 
	 * @return column value
	 */
	public int getCol() {
		return column;
	}

	/**
	 * 
	 * @return row value
	 */
	public int getRow() {
		return row;
	}
	
	/**
	 * 
	 * @return coordinates value in the array
	 */
	@Override
	public String toString() {
		return "Coordinate [ x = " + getRow() + ", y = " + getCol() + " ]";
	}

	/**
	 * 
	 * @return returns the coordinate�s values in a user-friendly format. Instead of
	 * Coordinate [x = 2, y = 0] this method returns: C-1
	 * @throws InvalidCoordinateException 
	 */
	public String toUserString(){
		char[] elements = {'A','B','C','D','E','F','G','H','I','J'};
		int[] values = {1,2,3,4,5,6,7,8,9,10};
		StringBuilder sb = new StringBuilder();
		sb.append(elements[coordinate[0]]+"-"+values[coordinate[1]]);
		return sb.toString();
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return Objects.hash(column, row);
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Coordinate that = (Coordinate) obj;
        return column == that.column && row == that.row;
	}
	
	/**
	 * Returns a new Coordinate object, next to this coordinate, moving to the direction received as 
	 * argument NORTH, EAST, SOUTH, or WEST
	 * @param direction where you want to go 
	 * @return a coordinate with the new direction you have chosen
	 */
	public Coordinate go(Direction direction) {
		switch(direction){
			case NORTH:
				return new Coordinate(this.column -1,this.row);
            case EAST:
                return new Coordinate(this.column, this.row + 1);
            case SOUTH:
                return new Coordinate(this.column + 1, this.row);
            case WEST:
                return new Coordinate(this.column, this.row - 1);
            default:
                throw new IllegalArgumentException("Invalid direction");
		}
	}
}
