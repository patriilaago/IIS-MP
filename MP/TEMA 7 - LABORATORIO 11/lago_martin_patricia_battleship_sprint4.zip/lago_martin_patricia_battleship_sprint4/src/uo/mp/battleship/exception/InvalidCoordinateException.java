package uo.mp.battleship.exception;

import uo.mp.battleship.model.board.Coordinate;

public class InvalidCoordinateException extends Exception{

	private static final long serialVersionUID = 1L;
	private Coordinate coordinate;
	
	public InvalidCoordinateException(Coordinate c) {
		super(String.format("(%s) is out of the board. You lose your turn",c.toUserString()));
		this.coordinate=c;
	}
	
	public Coordinate getCoordinate() {
		return coordinate;
	}
}
