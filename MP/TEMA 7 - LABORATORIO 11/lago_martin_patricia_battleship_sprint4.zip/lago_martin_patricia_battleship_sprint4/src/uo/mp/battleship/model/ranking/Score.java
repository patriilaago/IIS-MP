package uo.mp.battleship.model.ranking;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import uo.mp.battleship.session.GameLevel;

public class Score {

	private String username;
	private GameLevel level;
	private LocalDateTime initial;
	private LocalDateTime end;
	
	public Score(String userName, GameLevel level, LocalDateTime initial, LocalDateTime end){
		this.username=userName;
		this.level=level;
		this.initial=initial;
		this.end=end;
	}
	
	/**
	 * 
	 * @return the value of userName field
	 */
	public String getUserName() {
		return username;
	}
	
	/**
	 * 
	 * @return the value of elapsed time field in seconds
	 */
	public long getTime() {
		return ChronoUnit.SECONDS.between(initial, end);
	}
	
	/**
	 * 
	 * @return the value of level field

	 */
	public GameLevel getLevel() {
		return level;
	}
	
	/**
	 * 
	 * @return the value of date field
	 */
	public LocalDateTime getEndTime() {
		// TODO Auto-generated method stub
		return end;
	}	
}
