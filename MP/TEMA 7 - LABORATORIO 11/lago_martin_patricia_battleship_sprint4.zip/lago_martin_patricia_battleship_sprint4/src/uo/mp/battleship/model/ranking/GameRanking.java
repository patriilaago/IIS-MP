package uo.mp.battleship.model.ranking;

import java.util.ArrayList;
import java.util.List;

public class GameRanking {

	
	private List<Score> scores = new ArrayList<>();
	
	/**
	 * It adds the argument to the end of the list of scores.
	 * @param score
	 */
	public void append(Score score) {
		scores.add(score);
	}
	
	/**
	 * 
	 * @return It returns a copy of the list of scores
	 */
	public List<Score> getRanking(){
		return new ArrayList<Score>(scores);
	}
	
	/**
	 * 
	 * @param userName 
	 * @return a list containing only those scores of the userName
	 */
	public List<Score> getRankingFor(String userName){
		List<Score> ranking = new ArrayList<>();
		for(Score score: scores) {
			if(score.getUserName().equals(userName)) {
				ranking.add(score);
			}
		}
		return ranking;
	}
	
}
