package uo.mp.battleship.console;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import uo.mp.battleship.interaction.SessionInteractor;
import uo.mp.battleship.menu.Menu;
import uo.mp.battleship.model.ranking.Score;
import uo.mp.battleship.session.GameLevel;
import uo.mp.util.check.ArgumentChecks;
import uo.mp.util.console.Console;

public class ConsoleSessionInteractor implements SessionInteractor {

	private Menu menu = new Menu( new String[]{
			"Play a new game",
			"Show my results",
			"Show all results"
		});
	
	
	@Override
	public GameLevel askGameLevel() {
		System.out.println("Level (s)ea, (o)cean, (p)lanet ? ");
		char option = Console.readChar();
		switch(option) {
		case 's':
			return GameLevel.SEA;
		case 'o':
			return GameLevel.OCEAN;	
		case 'p':
			return GameLevel.PLANET;	
		default:
			throw new IllegalArgumentException("The character for the level is wrong");
		}
	}
	
	@Override
	public String askUserName() {
		System.out.println("Player name? ");
		return Console.readString();
	}

	@Override
	public int askNextOption() {
		return menu.askOption();
	}

	@Override
	public boolean askDebugMode() {
		Console.print("Do you want to play in debug mode (y)es, (n)o ? ");
		char c = String.valueOf( Console.readChar() ).toLowerCase().charAt( 0 );
		return c == 'y';
	}

	@Override
	public boolean doYouWantToRegisterYourScore() {
		Console.print("Do you want to store your score (y)es, (n)o ? ");
		char c = String.valueOf( Console.readChar() ).toLowerCase().charAt( 0 );
		return c == 'y';
	}

	@Override
	public void showRanking(List<Score> ranking) {
		ArgumentChecks.isNotNull( ranking );
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd\tHH:mm:ss     ");
		Console.println("User name\t.Date\t\t.Hour\t\t.Level\t.Time");
		for (Score rl: ranking) {		
			LocalDateTime dateTime = rl.getEndTime();
			String formattedDateTime = dateTime.format(formatter);
			String s = String.format(
					"%-10.10s\t%-20.20s\t%-6.6s\t%4d",
						rl.getUserName(),
						formattedDateTime,
						rl.getLevel(),
						rl.getTime()
					);
			Console.println( s );
		}		
	}

	@Override
	public void showPersonalRanking(List<Score> ranking) {
		ArgumentChecks.isNotNull( ranking );
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd\tHH:mm:ss     ");
		Console.println("Date\t\t.Hour\t\t.Level\t.Time");

		for (Score rl: ranking) {
			LocalDateTime dateTime = rl.getEndTime();
			String formattedDateTime = dateTime.format(formatter);
			String s = String.format(
					"%-20.20s\t%-6.6s\t%4d",
						formattedDateTime,
						rl.getLevel(),
						rl.getTime()
					);
			Console.println( s );
		}		
	}

	@Override
	public void showErrorMessage(String message) {
		Console.printError("ERROR: ");
		Console.printError( message );
		Console.printError("Please, try it again.");		
	}

	@Override
	public void showFatalErrorMessage(String message) {
		Console.printError("FATAL ERROR:");
		Console.printError( message );
		Console.printError("The program must stop execution.");		
	}

	@Override
	public void sayGoodbye() {
		// TO DO
		System.out.println("Thank you for playing battleship. Bye bye!");
	}

	@Override
	public void showMenu() {
		menu.showOptions();		
	}
	

}
