package uo.mp.lab11.person;

public class Person implements Comparable<Person>{
	private String name;
	private String surname;
	private int age;

	public Person(String name, String surname, int age) {
		this.name = name;
		this.surname = surname;
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	public String getSurname() {
		return surname;
	}

	@Override
	public String toString() {
		return name + " " + surname;
	}

	@Override
	public int compareTo(Person o) {
		// TODO Auto-generated method stub
		if(this.surname.compareTo(o.getSurname())!=0) {
			return this.surname.compareTo(o.getSurname());
		}
		else {
			if(this.name.compareTo(o.getName())!=0) {
				return this.name.compareTo(o.getName());
			}
			else {
				return this.age-o.getAge();
			}
		}
	}

}