package uo.mp.lab11.person;

import java.util.Comparator;

public class PersonComparator implements Comparator<Person>{

	@Override
	public int compare(Person o1, Person o2) {
		// TODO Auto-generated method stub
		if(o1.getSurname().compareTo(o2.getSurname())!=0) {//NOT EQUAL
			return o1.getSurname().compareTo(o2.getSurname());
		}
		else {
			if(o1.getName().compareTo(o2.getName())!=0) {
				return o1.getName().compareTo(o2.getName());
			}
			else {
				return o1.getAge()-o2.getAge();
			}
		}
	}

}
