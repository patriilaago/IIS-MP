package uo.mp.lab03.dome.model;

import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;

public abstract class Item {
    private String title;
    private boolean gotIt; // I have my own copy of the Cd
    private String comment;
    private double base_price;

    // Package protected
    /**
     * Creates a new Item
     * 
     * @param theTitle String for the title of the item
     */
    Item(String theTitle) {
	setTitle(theTitle);
	setOwn(false);
	setComment("No comment");
	setBasePrice(5.0);
    }

    /**
     * 
     * @param price double with the base price of the item
     */
    public void setBasePrice(double price) {
	ArgumentChecks.isTrue(price > 0.0, "The base price cannot be lower than 0");
	this.base_price = price;
    }

    /**
     * 
     * @return the base price of the item
     */
    public double getBasePrice() {
	return base_price;
    }

    /**
     * 
     * @param arg String with the new title
     * @throws IllegalArgumentException if the argument is null, 0-length or does not contain meaningful characters
     */
    private void setTitle(String arg) {
	ArgumentChecks.isTrue(arg != null && !arg.isBlank(), "Invalid title");

	this.title = arg;
    }

    /**
     * @return the comment (if any) or default
     */
    public String getTitle() {
	return title;
    }

    /**
     * 
     * @param boolean true means we own a copy; otherwise, false
     */
    public void setOwn(boolean ownIt) {
	gotIt = ownIt;
    }

    /**
     * @return true if we own a copy; false otherwise
     */
    public boolean getOwn() {
	return gotIt;
    }

    /**
     * 
     * @param arg String with a new comment to the element
     * @implNote If the argument is null or does not contain meaningful characters (other than blanks, new lines, etc)
     *           previous comment stays as it is
     */
    public void setComment(String arg) {
	if (arg != null && !arg.isBlank()) {
	    this.comment = arg;
	}
    }

    /**
     * @return the comment (if any) or default
     */
    public String getComment() {
	return comment;
    }

    /**
     * Prints the information about the item
     * 
     * @param out a PrintStream to flush output
     */

    String getUserDetails() {
	StringBuilder sb = new StringBuilder();
	sb.append("Got it: ");
	if (getOwn()) {
	    sb.append("You own it" + ", ");
	} else {
	    sb.append("You do not own it" + ", ");
	}
	sb.append("Comment: " + getComment());
	return sb.toString();
    }

    public abstract String print();

    @Override
    public int hashCode() {
	return Objects.hash(title);
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	Item other = (Item) obj;
	return Objects.equals(title, other.title);
    }

    @Override
    public String toString() {
	return " [title=" + title + ", " + getUserDetails();
    }

    public abstract String getResponsible();

    public abstract double getPrice();

    /**
     * Generates code of an item
     * 
     * @return code formed by the first 3 letters of the title
     */
    public String generateCode() {
	String word = "";
	for (int i = 0; i < 3; i++) {
	    word = word + getTitle().charAt(i);
	}
	return word;
    }
}
