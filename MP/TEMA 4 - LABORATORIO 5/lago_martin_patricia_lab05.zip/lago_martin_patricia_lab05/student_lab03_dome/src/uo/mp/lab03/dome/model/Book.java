package uo.mp.lab03.dome.model;

import java.util.Objects;

import uo.mp.lab03.dome.service.Borrowable;
import uo.mp.util.check.ArgumentChecks;

public class Book extends Item implements Borrowable {

    private String writer;
    private String publisher;
    private String ISBN;
    private boolean isAvailable;

    /**
     * Creates a new book with the default values for gotIt, comment and available
     * 
     * @param theTitle  title of the book
     * @param writer    person that wrote the book
     * @param publisher company that publishes the book
     * @param ISBN      code of the book
     */
    public Book(String theTitle, String writer, String publisher, String ISBN) {
	super(theTitle);
	setWriter(writer);
	setPublisher(publisher);
	setISBN(ISBN);
	setAvailable(isAvailable);
    }

    /**
     * 
     * @return string with the writer of the book
     */
    public String getWriter() {
	return writer;
    }

    /**
     * 
     * @param writer of the book
     */
    public void setWriter(String writer) {
	ArgumentChecks.isTrue(writer != null && !writer.isBlank(), "The writer of the book cannot be null or blank");
	this.writer = writer;
    }

    /**
     * 
     * @return string with the publisher of the book
     */
    public String getPublisher() {
	return publisher;
    }

    /**
     * 
     * @param publisher of the book
     */
    public void setPublisher(String publisher) {
	ArgumentChecks.isTrue(publisher != null && !publisher.isBlank(),
		"The publisher of the book cannot be null or blank");
	this.publisher = publisher;
    }

    /**
     * 
     * @return string with the ISBN of the book
     */
    public String getISBN() {
	return ISBN;
    }

    /**
     * 
     * @param iSBN of the book
     */
    public void setISBN(String iSBN) {
	ArgumentChecks.isTrue(iSBN != null && !iSBN.isBlank(), "The ISBN of the book cannot be null or blank");
	ISBN = iSBN;
    }

    /**
     * 
     * @return boolean value isAvailable. True in case the book is available, false otherwise.
     */
    public boolean getAvailable() {
	return isAvailable;
    }

    /**
     * 
     * @param isAvailable flag saying if the borrowable item is available or not
     */
    public void setAvailable(boolean isAvailable) {
	this.isAvailable = isAvailable;
    }

    @Override
    public String print() {
	StringBuilder sb = new StringBuilder();
	sb.append("Book: " + getTitle() + ", ");
	sb.append("Writer: " + getWriter() + ", ");
	sb.append("Publisher: " + getPublisher() + ", ");
	sb.append("ISBN: " + getISBN() + ", ");
	sb.append(super.getUserDetails());
	return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (!super.equals(obj))
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	Book other = (Book) obj;
	return Objects.equals(ISBN, other.ISBN);
    }

    @Override
    public String getResponsible() {
	return writer;
    }

    @Override
    public double getPrice() {
	return (getBasePrice() * 0.04) + getBasePrice();
    }

    @Override
    public void borrow() {
	if (getOwn() == true && isAvailable()) {
	    setAvailable(false);
	    setOwn(false);
	}
    }

    @Override
    public void giveBack() {
	if (!isAvailable() && !getOwn()) {
	    setAvailable(true);
	    setOwn(true);
	}
    }

    @Override
    public boolean isAvailable() {
	return getAvailable();
    }

    @Override
    public String returnTitle() {
	// TODO Auto-generated method stub
	return getTitle();
    }
}
