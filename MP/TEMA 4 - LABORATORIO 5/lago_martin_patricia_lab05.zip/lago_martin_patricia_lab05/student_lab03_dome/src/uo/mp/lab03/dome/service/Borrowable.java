package uo.mp.lab03.dome.service;

public interface Borrowable {

    public void borrow();

    public void giveBack();

    public boolean isAvailable();

    public String returnTitle();
}
