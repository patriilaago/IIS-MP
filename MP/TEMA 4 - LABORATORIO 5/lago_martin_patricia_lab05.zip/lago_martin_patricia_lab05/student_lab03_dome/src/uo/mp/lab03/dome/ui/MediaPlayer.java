package uo.mp.lab03.dome.ui;

import uo.mp.lab03.dome.model.Book;
import uo.mp.lab03.dome.model.Cd;
import uo.mp.lab03.dome.model.Dvd;
import uo.mp.lab03.dome.model.Videogame;
import uo.mp.lab03.dome.service.MediaLibrary;

public class MediaPlayer {

    public void run() {
	MediaLibrary ml = new MediaLibrary();
	// CD 1
	String theTitle = "Come Together";
	String theArtist = "Beatles";
	int theTime = 70;
	int theTracks = 4;
	// CD 2
	String theTitle2 = "Future Nostalgia";
	String theArtist2 = "Dua Lipa";
	int theTime2 = 60;
	int theTracks2 = 14;
	// CD 3
	String theTitle3 = "My 21st Century Blues";
	String theArtist3 = "Raye";
	int theTime3 = 75;
	int theTracks3 = 15;
	// DVD
	String theTitle_DVD = "The fantastic Mr. Fox";
	String theDirector = "Wes Anderson";
	int duration_film = 120;
	// Videogame
	String theTitle_VIDEOGAME = "The Last Of Us";
	String theAuthor = "Naughty dog";
	// Book 1
	String title_book = "It ends with us";
	String writer = "Colleen Hoover";
	String publisher = "Planeta";
	String ISBN = "A8888";
	// Book 2
	String title_book2 = "The perks of being a wallflower";
	String writer2 = "Stephen Chbosky";
	String publisher2 = "Planeta";
	String ISBN2 = "A5555";

	Cd cd = new Cd(theTitle, theArtist, theTracks, theTime);
	Cd cd2 = new Cd(theTitle2, theArtist2, theTracks2, theTime2);
	Cd cd3 = new Cd(theTitle3, theArtist3, theTracks3, theTime3);
	Dvd dvd = new Dvd(theTitle_DVD, theDirector, duration_film);
	Videogame videogame = new Videogame(theTitle_VIDEOGAME, theAuthor, uo.mp.lab03.dome.model.Platform.PLAYSTATION);
	Book book = new Book(title_book, writer, publisher, ISBN);
	Book book2 = new Book(title_book2, writer2, publisher2, ISBN2);

	// OWNED
	cd.setOwn(true);
	cd2.setOwn(true);
	cd3.setOwn(true);
	book.setOwn(true);
	book2.setOwn(true);
	cd.setAvailable(true);
	cd2.setAvailable(true);
	cd3.setAvailable(true);
	book.setAvailable(true);
	book2.setAvailable(true);
	// ADD TO LIBRARY
	ml.add(cd);
	ml.addBorrowable(cd);
	ml.add(cd2);
	ml.addBorrowable(cd2);
	ml.add(cd3);
	ml.addBorrowable(cd3);
	ml.add(dvd);
	ml.add(videogame);
	ml.add(book);
	ml.addBorrowable(book);
	ml.add(book2);
	ml.addBorrowable(book2);

	ml.borrow(book);
	ml.borrow(cd);

	System.out.println("-----responsables-----");
	System.out.println(ml.getResponsibles());
	System.out.println("-----Catalogue-----");
	System.out.println(ml.list());
	System.out.println("-----Borrowables-----");
	System.out.println(ml.getBorrowables());
	System.out.println("-----Availables-----");
	System.out.println(ml.getAvailables());

    }
}
