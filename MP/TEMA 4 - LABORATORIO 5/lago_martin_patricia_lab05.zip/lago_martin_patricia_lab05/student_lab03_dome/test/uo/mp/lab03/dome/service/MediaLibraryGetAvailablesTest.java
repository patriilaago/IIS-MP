package uo.mp.lab03.dome.service;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.lab03.dome.model.Book;
import uo.mp.lab03.dome.model.Cd;

public class MediaLibraryGetAvailablesTest {

    private Book book;
    private String title_book;
    private String writer;
    private String publisher;
    private String ISBN;
    private Cd cd;
    private String title_cd;
    private String artist;
    private int numberOfTracks;
    private int playingTime;

    @BeforeEach
    void setUp() {
	title_book = "It ends with us";
	writer = "Colleen Hoover";
	publisher = "Planeta";
	ISBN = "A647632";
	title_cd = "Future Nostalgia";
	artist = "Dua Lipa";
	numberOfTracks = 13;
	playingTime = 70;
	book = new Book(title_book, writer, publisher, ISBN);
	cd = new Cd(title_cd, artist, numberOfTracks, playingTime);
    }

    /**
     * GIVEN: a library with just a book that is available
     * WHEN: getAvailables()
     * THEN: we receive the title of the book that is available
     */
    @Test
    void getBookAvailability() {
	MediaLibrary ml = new MediaLibrary();
	book.setAvailable(true);
	ml.add(book);
	assertEquals("It ends with us" + "\n", ml.getAvailables());
    }

    /**
     * GIVEN: a library with just a cd that is available
     * WHEN: getAvailables()
     * THEN: we receive the title of the cd that is available
     */
    @Test
    void getCdAvailability() {
	MediaLibrary ml = new MediaLibrary();
	cd.setAvailable(true);
	ml.add(cd);
	assertEquals("Future Nostalgia" + "\n", ml.getAvailables());
    }

    /**
     * GIVEN: a library with a book and a cd that are available
     * WHEN: getAvailables()
     * THEN: we receive the titles of the book and cd that are available
     */
    @Test
    void getBookAndCdAvailables() {
	MediaLibrary ml = new MediaLibrary();
	book.setAvailable(true);
	cd.setAvailable(true);
	ml.add(book);
	ml.add(cd);
	assertEquals("It ends with us" + "\n" + "Future Nostalgia" + "\n", ml.getAvailables());
    }

    /**
     * GIVEN: a library with a book and a cd that are not available
     * WHEN: getAvailables()
     * THEN: we receive the empty string because there are no available items
     */
    @Test
    void getBookAndCdNotAvailables() {
	MediaLibrary ml = new MediaLibrary();
	ml.add(cd);
	ml.add(book);
	assertEquals("", ml.getAvailables());
    }

}
