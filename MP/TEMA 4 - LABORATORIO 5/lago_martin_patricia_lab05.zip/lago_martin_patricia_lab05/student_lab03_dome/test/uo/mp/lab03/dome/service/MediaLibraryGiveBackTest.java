package uo.mp.lab03.dome.service;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.lab03.dome.model.Book;
import uo.mp.lab03.dome.model.Cd;

public class MediaLibraryGiveBackTest {

    private Book book;
    private String title_book;
    private String writer;
    private String publisher;
    private String ISBN;
    private Cd cd;
    private String title_cd;
    private String artist;
    private int numberOfTracks;
    private int playingTime;

    @BeforeEach
    void setUp() {
	title_book = "It ends with us";
	writer = "Colleen Hoover";
	publisher = "Planeta";
	ISBN = "A647632";
	title_cd = "Future Nostalgia";
	artist = "Dua Lipa";
	numberOfTracks = 13;
	playingTime = 70;
	book = new Book(title_book, writer, publisher, ISBN);
	cd = new Cd(title_cd, artist, numberOfTracks, playingTime);
    }

    /**
     * GIVEN: a book we want to return to a catalogue that has another item(cd)
     * WHEN: giveBack()
     * THEN: the availability of the book will be true and also the own parameter
     */
    @Test
    public void returnValidBook() {
	MediaLibrary ml = new MediaLibrary();
	ml.addBorrowable(cd);
	book.setOwn(false);
	book.setAvailable(false);
	ml.giveBack(book);
	assertEquals(true, book.getAvailable());
    }

    /**
     * GIVEN: a cd we want to return to a catalogue that has another item(book)
     * WHEN: giveBack()
     * THEN: the availability of the cd will be true and also the own parameter
     */
    @Test
    public void returnValidCd() {
	MediaLibrary ml = new MediaLibrary();
	ml.addBorrowable(book);
	cd.setOwn(false);
	cd.setAvailable(false);
	ml.giveBack(cd);
	assertEquals(true, cd.getAvailable());
    }

    /**
     * GIVEN: a book we want to return and is already part of the catalogue
     * WHEN: giveBack()
     * THEN: the availability of the book and the gotIt parameter will stay as true
     */
    @Test
    public void returnNotValidBook() {
	MediaLibrary ml = new MediaLibrary();
	ml.addBorrowable(book);
	book.setAvailable(true);
	book.setAvailable(true);
	ml.giveBack(book);
	assertEquals(true, book.getAvailable());
    }

    /**
     * GIVEN: a cd we want to return and is already part of the catalogue
     * WHEN: giveBack()
     * THEN: the availability of the cd and the gotIt parameter will stay as true
     */
    @Test
    public void returnNotValidCd() {
	MediaLibrary ml = new MediaLibrary();
	ml.addBorrowable(cd);
	cd.setOwn(true);
	cd.setAvailable(true);
	ml.giveBack(cd);
	assertEquals(true, cd.getAvailable());
    }

}
