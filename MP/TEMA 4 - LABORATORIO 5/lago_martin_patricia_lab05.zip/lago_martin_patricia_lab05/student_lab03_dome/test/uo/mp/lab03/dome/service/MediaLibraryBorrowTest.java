package uo.mp.lab03.dome.service;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.lab03.dome.model.Book;
import uo.mp.lab03.dome.model.Cd;

public class MediaLibraryBorrowTest {

    private Book book;
    private String title_book;
    private String writer;
    private String publisher;
    private String ISBN;
    private Cd cd;
    private String title_cd;
    private String artist;
    private int numberOfTracks;
    private int playingTime;

    @BeforeEach
    void setUp() {
	title_book = "It ends with us";
	writer = "Colleen Hoover";
	publisher = "Planeta";
	ISBN = "A647632";
	title_cd = "Future Nostalgia";
	artist = "Dua Lipa";
	numberOfTracks = 13;
	playingTime = 70;
	book = new Book(title_book, writer, publisher, ISBN);
	cd = new Cd(title_cd, artist, numberOfTracks, playingTime);
    }

    /**
     * GIVEN: a book we want to borrow from a catalogue that has got that book
     * WHEN: borrow()
     * THEN: the availability of the book will be false and also the own parameter
     */
    @Test
    public void returnValidBook() {
	MediaLibrary ml = new MediaLibrary();
	ml.addBorrowable(book);
	book.setOwn(true);
	book.setAvailable(true);
	ml.borrow(book);
	assertEquals(false, book.getAvailable());
    }

    /**
     * GIVEN: a cd we want to borrow to a catalogue that has got that cd
     * WHEN: borrow()
     * THEN: the availability of the cd will be false and also the own parameter
     */
    @Test
    public void returnValidCd() {
	MediaLibrary ml = new MediaLibrary();
	ml.addBorrowable(cd);
	cd.setOwn(true);
	cd.setAvailable(true);
	ml.borrow(cd);
	assertEquals(false, cd.getAvailable());
    }

    /**
     * GIVEN: a book we want to borrow from a catalogue that hasn't got that book
     * WHEN: borrow()
     * THEN: the availability of the book and the gotIt parameter will stay as false
     */
    @Test
    public void returnNotValidBook() {
	MediaLibrary ml = new MediaLibrary();
	ml.addBorrowable(book);
	book.setAvailable(false);
	book.setAvailable(false);
	ml.borrow(book);
	assertEquals(false, book.getAvailable());
    }

    /**
     * GIVEN: a cd we want to borrow from a catalogue that hasn't got that cd
     * WHEN: borrow()
     * THEN: the availability of the cd and the gotIt parameter will stay as false
     */
    @Test
    public void returnNotValidCd() {
	MediaLibrary ml = new MediaLibrary();
	ml.addBorrowable(cd);
	cd.setOwn(false);
	cd.setAvailable(false);
	ml.borrow(cd);
	assertEquals(false, cd.getAvailable());
    }
}
