package uo.mp.lab03.dome.service;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uo.mp.lab03.dome.model.Book;
import uo.mp.lab03.dome.model.Cd;
import uo.mp.lab03.dome.model.Dvd;
import uo.mp.lab03.dome.model.Platform;
import uo.mp.lab03.dome.model.Videogame;

public class MediaLibraryGetBorrowablesTest {

    private Book book;
    private String title_book;
    private String writer;
    private String publisher;
    private String ISBN;
    private Cd cd;
    private String title_cd;
    private String artist;
    private int numberOfTracks;
    private int playingTime;
    private Dvd dvd;
    private String theTitle_dvd;
    private String theDirector_dvd;
    private int theTime_dvd;
    private Videogame game;
    private String theTitle_videogame;
    private String theAuthor_videogame;
    private Platform thePlatform;

    @BeforeEach
    void setUp() {
	title_book = "It ends with us";
	writer = "Colleen Hoover";
	publisher = "Planeta";
	ISBN = "A647632";
	title_cd = "Future Nostalgia";
	artist = "Dua Lipa";
	numberOfTracks = 13;
	playingTime = 70;
	theTitle_dvd = "Star Wars";
	theDirector_dvd = "George Lucas";
	theTime_dvd = 125;
	theTitle_videogame = "Animal Crossing";
	theAuthor_videogame = "Nintendo";
	thePlatform = Platform.XBOX;
	book = new Book(title_book, writer, publisher, ISBN);
	cd = new Cd(title_cd, artist, numberOfTracks, playingTime);
	dvd = new Dvd(theTitle_dvd, theDirector_dvd, theTime_dvd);
	game = new Videogame(theTitle_videogame, theAuthor_videogame, thePlatform);
    }

    /**
     * GIVEN: a library with a book,a cd, a videogame and a dvd
     * WHEN: getBorrowables()
     * THEN: we receive the title of the cd and book because they are the only ones from the library that are borrowable
     */
    @Test
    public void twoBorrowables() {
	MediaLibrary ml = new MediaLibrary();
	ml.add(cd);
	ml.add(book);
	ml.add(game);
	ml.add(dvd);
	String result = "Future Nostalgia" + "\n" + "It ends with us" + "\n";
	assertEquals(result, ml.getBorrowables());
    }

    /**
     * GIVEN: a library with a book and a cd that are not available
     * WHEN: getBorrowables()
     * THEN: we receive the empty string because there are no borrowable items
     */
    @Test
    public void noBorrowables() {
	MediaLibrary ml = new MediaLibrary();
	ml.add(game);
	ml.add(dvd);
	assertEquals("", ml.getBorrowables());
    }

    /**
     * GIVEN: a library with a book, a dvd and a videogame
     * WHEN: getBorrowables()
     * THEN: we just receive the title of the cd because is the only item from the library that is borrowable
     */
    @Test
    public void oneBorrowable() {
	MediaLibrary ml = new MediaLibrary();
	ml.add(cd);
	ml.add(game);
	ml.add(dvd);
	String result = "Future Nostalgia" + "\n";
	assertEquals(result, ml.getBorrowables());
    }

}
