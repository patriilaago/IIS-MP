package uo.mp.util.collections.impl;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;
import uo.mp.util.collections.List;


public class ArrayList implements List {

	private final static int INITIAL_CAPACITY = 20;
	
	private Object[] elements;
	private int numberOfElements;

	
	public ArrayList(int capacity) {
		this.elements= new Object[capacity];
		this.numberOfElements=0;
	}
	
	public ArrayList() {
		this(INITIAL_CAPACITY);
	}
	
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return numberOfElements;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return this.size() == 0;
	}

	@Override
	public boolean contains(Object o) {
		// TODO Auto-generated method stub
		return search(o) != -1;
	}
	
	private int search(Object obj) {
		for (int i = 0; i < size(); i++) {
			if (elements[i].equals(obj)) {
				return i;
			}
		}
		return -1;
	}

	@Override
	public boolean add(Object element) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(element!=null, "The object you want to add cannot be null");
		if (size() >= this.elements.length) {
			this.moreMemory();
		}
		this.elements[numberOfElements] = element;
		this.numberOfElements++;
		return true;
	}

	private void moreMemory() {
		Object[] aux = new Object[2 * elements.length];
		System.arraycopy(elements, 0, aux, 0,elements.length);
		elements = aux;
	}
	
	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(o!=null, "The object you want to remove cannot be null");
		if(indexOf(o) != -1) {
			return remove(indexOf(o)) != null;
		} 
		else {
			return false;
		}
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		for (int i = 0; i < size(); i++) {
			elements[i] = null;
		}
		numberOfElements = 0;
	}

	@Override
	public Object get(int index) {
		// TODO Auto-generated method stub
		if(index<0 || index>=size() || isEmpty()) {
			throw new IndexOutOfBoundsException("The element you want to get is out of the limits");
		}
		return elements[index];
	}

	@Override
	public Object set(int index, Object element) {
		// TODO Auto-generated method stub
		if(index<0 || index>=elements.length) {
			throw new IndexOutOfBoundsException("The index of the element you want to set is out of the limits");
		}
		ArgumentChecks.isTrue(element != null, "The element you want to set cannot be null");
		Object before = elements[index];
		elements[index] = element;
		return before;
	}

	@Override
	public void add(int index, Object element) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(element!=null, "The object you want to add cannot be null");
		if(index<0 || index>=elements.length) {
			throw new IndexOutOfBoundsException("The index of the element you want to add is out of the limits");
		}
		if (size() >= this.elements.length) {
			this.moreMemory(); 
		}
		for(int i = size(); i > index; i--) {
			elements[i] = elements[i - 1];
		}
		elements[index] = element;
		numberOfElements++;
	}

	@Override
	public Object remove(int index) {
		// TODO Auto-generated method stub
		if(index<0||index>numberOfElements) {
			throw new IndexOutOfBoundsException("The index of the element you want to remove is out of the limits");
		}
		if(this.isEmpty()) {
			throw new IndexOutOfBoundsException("You can't remove an element from an empty list");
		}
		Object value = elements[index];
		for(int j=index; j < size()-1; j++){
			elements[j] = elements[j+1];
		}
		numberOfElements--;
		elements[numberOfElements] = null;
		return value;
	}

	@Override
	public int indexOf(Object o) {
		// TODO Auto-generated method stub
		return search(o);
	}



	@Override
	public int hashCode() {
		if(isEmpty()) {
			return 1;
		}
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(elements);
		result = prime * result + numberOfElements;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ArrayList other = (ArrayList) obj;
		if (!Arrays.deepEquals(elements, other.elements))
			return false;
		if (numberOfElements != other.numberOfElements)
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("[");
		for(int i = 0; i < size(); i++) {
			sb.append(elements[i]);
				if(i < size() - 1) {
					sb.append(", ");
				}
		}
		sb.append("]");
		return sb.toString();
	}
	
	@Override
	public Iterator<Object> iterator() {
		// TODO Auto-generated method stub
		return  new ArrayListIterator();
	}

	private class ArrayListIterator implements Iterator<Object>{

		private int current_index = 0;
		
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return current_index < numberOfElements;
		}

		@Override
		public Object next() {
			// TODO Auto-generated method stub
			if(!hasNext()) {
				throw new NoSuchElementException("");
			}
			Object next = elements[current_index];
			current_index++;
			return next;
		}
	}
}
