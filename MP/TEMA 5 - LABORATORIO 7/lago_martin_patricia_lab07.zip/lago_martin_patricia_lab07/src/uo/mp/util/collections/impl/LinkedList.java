package uo.mp.util.collections.impl;

import java.util.Iterator;

import java.util.NoSuchElementException;
import java.util.Objects;

import uo.mp.util.check.ArgumentChecks;
import uo.mp.util.collections.List;

public class LinkedList implements List {

	private static class Node {
		Object value;
		Node next;
		
		Node(Object value, Node next) {
		this.value = value;
		this.next = next;
		}
	}
	
	private Node head;
	private int numberOfElements;
	
	public LinkedList() {
		this.head = null;
		this.numberOfElements = 0;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return this.numberOfElements;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return this.size() == 0;

	}

	@Override
	public boolean contains(Object o) {
		// TODO Auto-generated method stub
		return search(o) != -1;
	}
	
	private int search(Object o) {
		Node aux = head;
		int position = 0;
		while (aux != null && !aux.value.equals(o)) {
			aux = aux.next;
			position++;
		}
		return aux == null ? -1 : position;
	}

	private void addFirst(Object element) {
		// TODO Auto-generated method stub
		this.head = new Node(element,this.head);
		numberOfElements++;
	}
	
	@Override
	public void add(int index,Object element) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(element!=null, "The object you want to add cannot be null");
		if(index<0 || index>=size()) {
			throw new IndexOutOfBoundsException("The index of the element you want to add is out of the limits");
		}
		if (index==0)
			this.addFirst(element);
		else {
			Node previous = getNode(index-1);
			previous.next = new Node(element, previous.next);
			this.numberOfElements++;
		}
	}
	
	@Override
	public boolean add(Object element) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(element!=null, "The object you want to add cannot be null");
		if (this.isEmpty()) {
			addFirst(element);
			return true;
		}
		else {	
			Node last = getNode(size()-1);
			last.next = new Node(element, null);
			this.numberOfElements++;
			return true;
		}
	}

	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(o != null,"The object you want to remove cannot be null");
		int position = indexOf(o);
		if (position == -1) {
			return false;
		} 
		else {
			remove(position);
			return true;
		}
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		this.head = null;
		this.numberOfElements = 0;
	}

	@Override
	public Object get(int index) {
		// TODO Auto-generated method stub
		ArgumentChecks.isTrue(index>=0 && index < size() && !isEmpty(), "The element you want to get is out of the limits");
		return getNode(index).value;
	}
	
	private Node getNode(int index) {
//		int position = 0;
//		Node node = this.head;
//		while (position < index) {
//			node = node.next;
//			position++; 
//		}
//		return node;
		Node aux = head;
		for (int i = 0; i < index; i++) {
			aux = aux.next;
		}
		return aux;
	}

	@Override
	public Object set(int index, Object element) {
		// TODO Auto-generated method stub
		if(index<0||index>=numberOfElements) {
			throw new IndexOutOfBoundsException("The index of the element you want to get is out of the limits");
		}
		ArgumentChecks.isTrue(element != null, "The element you want to set cannot be null");
		getNode(index).value = element;
		return this;
	}

	@Override
	public Object remove(int index) {
		// TODO Auto-generated method stub
		if(this.isEmpty()) {
			throw new IndexOutOfBoundsException("You can't remove an element from an empty list");
		}
		if(index<0 || index>numberOfElements) {
			throw new IndexOutOfBoundsException("The index of the element you want to remove is out of the limits");
		}
		Object value;
		if (index == 0) { 
			value = head.value;
			head = head.next;
		} 
		else {
			Node previous = getNode(index - 1);
			value = previous.next.value;
			previous.next = previous.next.next;
		}
		this.numberOfElements--;
		return value;
//		Node current = head;
//        if (index == 0) {
//            head = current.next;
//        } else {
//            for (int i = 0; i < index - 1; i++) {
//                current = current.next;
//            }
//            current.next = current.next.next;
//        }
//        numberOfElements--;
//        return current.value;
	}

	@Override
	public int indexOf(Object o) {
		// TODO Auto-generated method stub
		return search(o);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("[");
		Node each = head;
		for(int i = 0; i < size(); i++) {
			sb.append(each.value);
				if(i < size() - 1) {
					sb.append(", ");
				}
			each = each.next;
		}
		sb.append("]");
		return sb.toString();
	}


	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((head == null) ? 0 : head.hashCode());
		result = prime * result + numberOfElements;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LinkedList other = (LinkedList) obj;
		if (head == null) {
			if (other.head != null)
				return false;
		} else if (!head.equals(other.head))
			return false;
		if (numberOfElements != other.numberOfElements)
			return false;
		return true;
	}

	@Override
	public Iterator<Object> iterator() {
		// TODO Auto-generated method stub
		return new LinkedListIterator();
	}
	
	private class LinkedListIterator implements Iterator<Object>{

		private Node current = head;
		
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return current != null;
		}

		@Override
		public Object next() {
			// TODO Auto-generated method stub
			if(!hasNext()) {
				throw new NoSuchElementException("There are no elements");
			}
			Object nodeToReturn = current.value;
			current = current.next;
			return nodeToReturn;
		}
	}

}
