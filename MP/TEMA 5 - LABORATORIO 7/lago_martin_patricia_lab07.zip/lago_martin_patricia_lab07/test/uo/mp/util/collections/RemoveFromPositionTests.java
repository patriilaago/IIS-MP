package uo.mp.util.collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.stream.Stream;

import org.junit.jupiter.api.Named;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import uo.mp.util.collections.impl.ArrayList;
import uo.mp.util.collections.impl.LinkedList;

/*
 * SCENARIOS
 * 	delOnlyItem Remove element at position 0 from a list with one element returns the removed element and the list is empty
 * 	delFirst Remove element at position 0 from a non-empty list returns the element removed, size decreases and move the rest of elements one position to the left
 * 	delMiddle Remove from an existing position (in the middle of the list) returns the removed element, the element is removed, elements are shift one position to the left
 * 	delLast Remove last element returns the removed element and the element is removed, others remain at the same position
 * 	testLowerBound Try to remove element at position -1 throws IndexOutOfBoundsException
 * 	emptyList Try to remove element at position 0 in an empty list throws IndexOutOfBoundsException
 *	testUpperBound Try to remove element at position size() in a non-empty list throws IndexOutOfBoundsException
 */
public class RemoveFromPositionTests {
	public static Stream<Arguments> createLists() {
		  return Stream.of(
		      Arguments.of(Named.of("ArrayList", new ArrayList())),
		      Arguments.of(Named.of("LinkedList", new LinkedList()))
		  );
		}

	/**
	 * GIVEN: a list with just an element
	 * WHEN: remove(first element)   
	 * THEN: the list now is empty
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void delOnlyItem(List list) {
		list.add("first");
		assertEquals("first",list.remove(0));
		assertEquals(true,list.isEmpty());
	}


	/**
	 * GIVEN: a list with three elements 
	 * WHEN:  remove(first element)  
	 * THEN: the size of the list decreases 1 unit
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void delFirst(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		assertEquals("first",list.remove(0));
		assertEquals(2,list.size());
	}
	
	/**
	 * GIVEN: a list with three elements 
	 * WHEN:  remove(last element)  
	 * THEN: the size of the list decreases 1 unit, and the index of the elements stays the same
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void delLast(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		
		int previous_position_first = list.indexOf("first");
		int previous_position_second = list.indexOf("second");
		
		assertEquals("third",list.remove(2));
		assertEquals(2,list.size());
		assertEquals(previous_position_first,list.indexOf("first"));
		assertEquals(previous_position_second,list.indexOf("second"));
	}

	
	/**
	 * GIVEN: a list with three elements 
	 * WHEN:  remove(middle element)  
	 * THEN: the size of the list decreases 1 unit, the index of the first element stays the same and the index of the last elements decreases
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void delMiddle(List list) {
		list.add("first");
		list.add("second");
		list.add("third");
		
		int previous_position_first = list.indexOf("first");
		int previous_position_last = list.indexOf("third");
		
		assertEquals("second",list.remove(1));
		assertEquals(2,list.size());
		assertEquals(previous_position_first,list.indexOf("first"));
		assertEquals(previous_position_last-1,list.indexOf("third"));
	}
	
	
	/**
	 * GIVEN: an empty list
	 * WHEN:  remove(first element)  
	 * THEN: an exception is thrown because because you can't remove an element from an empty list
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void emptyList(List list) {
		try {
			list.remove(0);
		}
		catch(Exception e) {
			assertEquals("You can't remove an element from an empty list",e.getMessage());
		}
	}
	

	/**
	 * GIVEN: a list with just one element
	 * WHEN: remove(index higher than size of the list)
	 * THEN: an exception is thrown because you want to remove an element from an index higher than the size of the list
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void testUpperBound(List list) {
		list.add("first");
		try {
			list.remove(5);
			fail();
		}
		catch(Exception e) {
			assertEquals("The index of the element you want to remove is out of the limits",e.getMessage());
		}
	}
	
	/**
	 * GIVEN: a list with just one element
	 * WHEN: remove(negative index)
	 * THEN: an exception is thrown because you want to remove an element from an index that doesn't exist
	 */
	@ParameterizedTest@MethodSource("createLists")
	public void testLowerBound(List list) {
		list.add("first");
		try {
			list.remove(-3);
			fail();
		}
		catch(Exception e) {
			assertEquals("The index of the element you want to remove is out of the limits",e.getMessage());
		}
	}
		

}
