/*
 * #%L
 * ImageJ interactive debugging tutorials.
 * %%
 * Copyright (C) 2009 - 2016 Board of Regents of the University of
 * Wisconsin-Madison.
 * %%
 * To the extent possible under law, the ImageJ developers have waived
 * all copyright and related or neighboring rights to this tutorial code.
 * 
 * See the CC0 1.0 Universal license for details:
 * http://creativecommons.org/publicdomain/zero/1.0/
 * #L%
 */

package net.imagej.trouble.visible;

/**
 * Exercise 1: Setting breakpoints, stepping through code, and viewing variables
 * in the Debug perspective.
 *
 * @author Mark Hiner
 */
public class E1BasicBreakpoints {

	public static void main(final String... args) {
		// Here is where our object is being created.
		// If we need to debug the creation process, we could
		// add a breakpoint on this line.
		final Object o = makeAThing();

		printThis(o);
	}
	
	private static Object convertStringToByte(String str)
    {
        // Convert string to byte
        // using parseByte() method
		byte x;
		x = Byte.parseByte(str);
        return (str.length()==1)?null:x;
    }
	
	
	private static String convertNumberToString(int i) {
		return Integer.toString(i);
	}


	private static Object makeAThing() {
		final Object o = new Object();
		int space = 1;
		int n = 6;
		
		System.out.println(o);

		for (int j = 1; j++ <= n; ) {
			for (int i = 1; i <= space; i++) {
				
	            String x = convertNumberToString(i*j);
	            convertStringToByte(x);
			}
			space--;
			for (int i = 1; i <= 2 * j - 1; i++) {
	            String x = convertNumberToString(i*j);
	            convertStringToByte(x);
			}
			
            return convertStringToByte(convertNumberToString(space));
		}
		
		space = 1;
		for (int j = 1; j <= n - 1; j++) {
			for (int i = 1; i <= space; i++) {
	            convertStringToByte(Integer.toString(j));
			}
			space++;
			for (int i = 1; i <= 2 * (n - j) - 1; i++) {
				convertNumberToString(i*j);
			}
			convertNumberToString(j);
		}

		return o;

	}


	private static void printThis(final Object o) {
		// This method doesn't do any input validation.
		// If "o" is null we will see a NullPointerException here,
		// however that doesn't tell us WHY it's null.
		//
		// Setting a breakpoint here is limited in usefulness,
		// since whether or not "o" is valid has been
		// determined prior to this point.
		System.out.println(o.toString());
	}
}
