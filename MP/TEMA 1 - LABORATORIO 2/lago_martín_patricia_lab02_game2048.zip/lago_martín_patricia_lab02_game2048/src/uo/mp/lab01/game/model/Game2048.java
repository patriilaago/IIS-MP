package uo.mp.lab01.game.model;



import uo.mp.util.check.ArgumentChecks;

/**
 * A simulation of the "2048" game, see http://juego2048.es/ Copyright (c) 2023 School of Computer Science - University
 * of Oviedo
 * The Game2048 class deals with the gameboard, setting up an array of elements and putting the array in a string. 
 * Most of the logic is also here, the class providing methods for spawning 2's at random locations, moving up, down, left and right, 
 * and letting players know when the game is over.
 * 
 * @author MP teachers
 * @version 1.0
 */
public class Game2048 {
	
	private int[][] board;
	private static final int MINIMUM_SIZE = 3;
	private static final int DEFAULT_SIZE = 3;
	private static final int MAXIMUM_SIZE = 5;
	private static final int EMPTY = 0;
	private static final int WINNING_NUMBER = 2048;
	
    /**
     * Creates a 3x3 board (default board) All cells set to 0
     */
    public Game2048() {
    	this.board=new int[DEFAULT_SIZE][DEFAULT_SIZE];
    }

    /**
     * Creates a squared board with the specified size, zeroes all its positions
     * 
     * @param size the desired size for the board
     * @throws IllegalArgumentException
     */
    public Game2048(int size) {
    	ArgumentChecks.isTrue(size >= MINIMUM_SIZE && size <= MAXIMUM_SIZE, "The size of the board cannot be lower than 3 or higher than 5");
    	this.board=new int[size][size];
    }

    /**
     * Constructor with an initial matrix as parameter Useful for testing purposes
     * 
     * @param board squared matrix, 3x3 to 5x5, containing only power-of-2 values. If size < 3 or size > 5 or some tile
     *              contains a non-power-of-2 value, default board is used instead
     * @throws IllegalArgumentException
     */
    Game2048(int[][] board) {
    	if(board==null) {
			throw new IllegalArgumentException("Null is not valid");
		}
    	boolean correct = true;
		//Checks that the matrix is squared and if the size is between the limits
		if(board.length==board[0].length && board.length>=DEFAULT_SIZE && board.length<=MAXIMUM_SIZE){
			for(int row=0;row<board.length;row++){
				for(int column=0;column<board[0].length;column++){
					//Throw an exception if we find a cell with a number that is not a poer of 2
					if(!powerOfTwoBitwise(board[row][column])) {
						correct = false;
					}
				}
			}
			if(correct==true) {
				this.board=new int[board.length][board[0].length];
					for(int row=0;row<board.length;row++){
						for(int column=0;column<board[0].length;column++){
							this.board[row][column]=board[row][column];
					   }
					}
			}
			else {
				this.board=new int[DEFAULT_SIZE][DEFAULT_SIZE];
			}
		}
		
		//When the matrix is not squared, we initialize a 3x3 matrix
		else {
			this.board=new int[DEFAULT_SIZE][DEFAULT_SIZE];
		}
    }

    /**
     * @param n integer number >= 0
     * 
     * @return true if n is a power-of-2 number; false otherwise
     */
    private boolean powerOfTwoBitwise(int n) {
    	return (n & n - 1) == 0;
    }

    /**
     * Returns the board. For testing purposes
     * 
     * @param the array
     */
    int[][] getBoard() {
    	int[][]copy= new int[board.length][board[0].length];
        for(int row=0;row<board.length;row++) {
        	for(int column=0;column<board[0].length;column++){
        		copy[row][column]=board[row][column];
        	}
        }
        return copy;
    }

    /**
     * A free position is a cell with a 0 value
     * 
     * @return true if there is no free positions on the board
     */
    public boolean isBoardFull() {
    	for(int row = 0 ; row<board.length ; row++) {
    		for(int column = 0 ; column<board[0].length ; column++) {
    			if(board[row][column]==EMPTY) {
    				return false; // Found a free position
    			}
    		}
    	}
    	return true; // No free positions found
    }

    /**
     * Pseudocode: For each row - slideRight (moves all non blank tiles to the right) - mergeRight (Move through the
     * vector; if two adjacent tiles are equal combines them doubling the value of the right tile and setting a zero on
     * the left one) - slideRight (again, as mergeRight has introduced new zeroes)
     */    
    public void moveRight() {
    	for(int[] row : board) {
    		slideRight(row);
    		mergeRight(row);
    		slideRight(row);
    	}
    }

    /*
     * @param vector that represents the row of the board, where we slide contiguous tiles to the right if 
     * 		it is empty.
     */
    private void slideRight(int[] vector) {
        int insertPosition = vector.length - 1;
        for (int position = vector.length - 1; position >= 0; position--) {
            if (vector[position] != 0) {
                vector[insertPosition] = vector[position];
                if (insertPosition != position) {
                    vector[position] = 0;
                }
                insertPosition--;
            }
        }
    }

    /**
     * @param vector to merge adding contiguous tiles to the right if contain the same value and replacing tile on the
     *               left with zero
     */
    private void mergeRight(int[] vector) {
        for (int position = vector.length - 1; position > 0; position--) {
            if (vector[position] == vector[position - 1]) {
                vector[position] *= 2;
                vector[position - 1] = 0;
            }
        }
    }

    /**
     * Move elements to the left with the same logic as in moveRight() By using the rotateBoard() method it is much
     * easier, it is a combination of rotate, rotate, move right, rotate, rotate
     */
    public void moveLeft() {
		rotateBoard();
		rotateBoard();
		moveRight();
		rotateBoard();
		rotateBoard();
    }

    /**
     * Move elements up with the same logic as in moveRight() By using the rotateBoard() method it is much easier, a
     * combination of rotations and moveRight
     */
    public void moveUp() {
    	rotateBoard();
    	moveRight();
    	rotateBoard();
    	rotateBoard();
    	rotateBoard();
    }

    /**
     * Move elements down with the same logic as in moveRight() By using the rotateBoard() method it is much easier, a
     * combination of rotations and moveRight
     */
    public void moveDown() {
    	rotateBoard();
    	rotateBoard();
    	rotateBoard();
    	moveRight();
    	rotateBoard();
    }

    /**
     * Rotates the board to the left (counterclockwise) Hint: create a new array and copy the values in the rotated
     * positions
     */
    private void rotateBoard() {
        int size = board.length;
        int[][] newBoard = new int[size][size];

        for (int row = 0; row < size; row++) {
            for (int column = 0; column < size; column++) {
                newBoard[column][size - 1 - row] = board[row][column];
            }
        }

        board = newBoard;
    }

    /**
     * Writes a 2 value on a random free tile, ensuring there is one.
     * 
     * @return true if there were a free tile; false otherwise.
     */
    public boolean next() {
        int emptyRow = -1;
        int emptyCol = -1;
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[0].length; col++) {
                if (board[row][col] == 0) { // Empty cell
                    emptyRow = row;
                    emptyCol = col;
                    break;
                }
            }
        }
        if (emptyRow != -1 && emptyCol != -1) {
            // Place the value 2 in the empty cell
            board[emptyRow][emptyCol] = 2;
            return true; // Successfully added a new value
        } 
        else {
            return false; // No empty cells left
        }
    }

    /**
     * @return a String with the content of the board to be printed out. Format each string so there are 5 spaces for
     *         every cell in the same row. Example: 2 2 0 2 0 0 2 0 2 will be
     *         "2....2....0....\n2....0....0....\n2....0....2...."
     */
    public String toString() {
        String result = "";
    	for (int row = 0; row < this.board.length; row++) {
    		for (int column = 0; column < this.board.length; column++) {
        		result+=board[row][column]+"....";
        	}
        	result+="\\n ";
        }
        return result;
    }

    /**
     * @return true if the player has won; a tile contains 2048 
     */
    public boolean win() {
    	for(int row = 0 ; row<board.length ; row++) {
    		for(int column = 0 ; column<board.length ; column++) {
    			if(board[row][column]==WINNING_NUMBER) {
    				return true;
    			}
    		}
    	}
    	return false;
    }
}
