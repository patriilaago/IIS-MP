package uo.mp.lab01.game.model;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import uo.mp.lab01.game.model.util.ForTesting;

/* 
 * Possible scenarios:
 * 1- One merge is possible
 * 2- No merge is possible
 * 3- Merges on a big board
 */

public class Game2048MoveUpTest {

	/*
	 * GIVEN: [[0,2,0],[0,2,0],[0,0,0]]
	 * WHEN: moveUp
	 * THEN: [[0,0,0],[0,4,0],[0,0,0]]
	 */
	@Test
	public void oneMerge() {
		int[][] first = ForTesting.HALF_FULL_MEDIUM_UP;
		int[][] result = ForTesting.HALF_FULL_MEDIUM_UP_RESULT;
		Game2048 game = new Game2048(first);
		game.moveUp();
		assertArrayEquals(result, game.getBoard() );
	}
	
	/*
	 * GIVEN: [[2,0,0],[0,0,0],[0,8,0]]
	 * WHEN: moveUp
	 * THEN: [[2,8,0],[0,0,0],[0,0,0]]
	 */
	@Test
	public void noMerge() {
		int[][] first = ForTesting.HALF_FULL_MEDIUM_NO_UP;
		int[][] result = ForTesting.HALF_FULL_MEDIUM_UP_NO_RESULT;
		Game2048 game = new Game2048(first);
		game.moveUp();
		assertArrayEquals(result, game.getBoard() );
	}
	

}
