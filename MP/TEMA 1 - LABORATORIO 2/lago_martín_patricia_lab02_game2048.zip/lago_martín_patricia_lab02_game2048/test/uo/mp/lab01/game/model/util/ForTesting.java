package uo.mp.lab01.game.model.util;

public class ForTesting {
    
    /*
     * Valid arrays
     */
    public final static int[][] EMPTY = { { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } };

    public final static int[][] FULL = { { 2, 2, 2 }, 
                                   { 2, 2, 2 }, 
                                   { 2, 2, 2 } };

    public final static int[][] HALF_FULL = { { 2, 0, 0 }, 
                                       { 2, 0, 0 }, 
                                       { 2, 0, 0 } };
   

    public static final int[][] MEDIUM_HALF_FULL =  { { 2, 0, 0, 0 },
                                                    { 2, 0, 0, 0 },
                                                    { 2, 0, 0, 0 },
                                                    { 2, 0, 0, 0 } };
    
    public static final int[][] MEDIUM_EMPTY =  { { 0, 0, 0, 0 },
                                                    { 0, 0, 0, 0 },
                                                    { 0, 0, 0, 0 },
                                                    { 0, 0, 0, 0 } };

    public static final int[][] BIG_EMTPY = { { 0, 0, 0, 0, 0 }, 
                                       { 0, 0, 0, 0, 0 }, 
                                       { 0, 0, 0, 0, 0 }, 
                                       { 0, 0, 0, 0, 0 }, 
                                       { 0, 0, 0, 0, 0 } };

    public static final int[][] BIG_HALF_FULL = { { 2, 0, 0, 0, 0 }, 
                                          { 2, 0, 0, 0, 0 }, 
                                          { 2, 0, 0, 0, 0 }, 
                                          { 2, 0, 0, 0, 0 }, 
                                          { 2, 0, 0, 0, 0 } };
    
    public static final int[][] HALF_FULL_2048 = { { 2, 0, 0, 0, 0 }, 
            { 2, 0, 0, 0, 0 }, 
            { 2, 0, 2048, 0, 0 }, 
            { 2, 0, 0, 0, 0 }, 
            { 2, 0, 0, 0, 0 } };   
    
    public static final int[][] FULL_2048 = { { 2, 2, 4, 2, 8 }, 
            { 2, 8, 64, 64, 32 }, 
            { 2, 2, 2048, 16, 8 }, 
            { 2, 2, 8, 256, 8 }, 
            { 2, 2, 16, 128, 512 } };   
    
    /*
     * Invalid arrays
     */
    public static final int[][] CORRUPTED_BOARD =  { { 2, 6, 0, 0 },
                                                    { 2, 0, 0, 0 },
                                                    { 2, 0, 0, 0 },
                                                    { 2, 0, 0, 0 } };
    
    public static final int[][] NOT_SQUARED_BOARD =  { { 2, 0, 0, 0 },
                                                    { 2, 0, 0, 0 },
                                                    { 2, 0, 0, 0 } };
    
    public static final int[][] TINY_BOARD = { { 2, 0 }, 
                                       { 2, 0 } };

    public static final int[][] TOO_BIG_BOARD = { { 2, 0, 0, 0, 0, 4 }, 
                                          { 2, 0, 0, 0, 0, 4 }, 
                                          { 2, 0, 0, 0, 0, 4 }, 
                                          { 2, 0, 0, 0, 0, 4 }, 
                                          { 2, 0, 0, 0, 0, 4 }, 
                                          { 2, 0, 0, 0, 0, 4 } };
    
   /*
    * CASES FOR THE MOVE METHODS
    */
    
    public final static int[][] HALF_FULL_TO_THE_LEFT = { { 0, 2, 2 }, 
            { 0, 0, 2 }, 
            { 0, 0, 2 } };

    public final static int[][] HALF_FULL_TO_THE_LEFT_RESULT = { { 4, 0, 0 }, 
            { 2, 0, 0 }, 
            { 2, 0, 0 } };
    
    public final static int[][] HALF_FULL_MEDIUM = { { 0, 2, 0 }, 
            { 0, 2, 0 }, 
            { 0, 2, 0 } };
     
    public final static int[][] HALF_FULL_MEDIUM_UP = { { 0, 2, 0 }, 
            { 0, 2, 0 }, 
            { 0, 0, 0 } };
    
    public final static int[][] HALF_FULL_MEDIUM_UP_RESULT = { { 0, 4, 0 }, 
            { 0, 0, 0 }, 
            { 0, 0, 0 } };
    
    public final static int[][] HALF_FULL_MEDIUM_NO_UP = { { 2, 0, 0 }, 
            { 0, 0, 0 }, 
            { 0, 8, 0 } };
    
    public final static int[][] HALF_FULL_MEDIUM_UP_NO_RESULT = { { 2, 8, 0 }, 
            { 0, 0, 0 }, 
            { 0, 0, 0 } };
    
    public final static int[][] HALF_FULL_DOWN = { { 0, 2, 2 }, 
            { 0, 0, 2 }, 
            { 0, 0, 2 } };
    
    public final static int[][] HALF_FULL_DOWN_RESULT = { { 0, 0, 0 }, 
            { 0, 0, 2 }, 
            { 0, 2, 4 } };
    
    public final static int[][] HALF_FULL_DOWN_NO = { { 0, 2, 2 }, 
            { 8, 0, 0 }, 
            { 0, 0, 0 } };
    
    public final static int[][] HALF_FULL_DOWN_NO_RESULT = { { 0, 0, 0 }, 
            { 0, 0, 0 }, 
            { 8, 2, 2 } };
    
 
    /**
     * Sums up all values in the board
     * 
     * @param matrix
     * @return result is the sum of every position in the matrix
     */
    public static int getSum(int[][] matrix) {
	int cont = 0;
	for (int i = 0; i < matrix.length; i++)
	    for (int j = 0; j < matrix[i].length; j++)
		cont = cont + matrix[i][j];
	return cont;
    }

}
