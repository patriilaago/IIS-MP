package uo.mp.lab01.game.model;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import uo.mp.lab01.game.model.util.ForTesting;

public class Game2048MoveLeftTest {
/*
 * Possible scenarios:
 * 1- One merge is possible
 * 2- No merge is possible
 * 3- MergeS on a big board
 */
	
	/*
	 * GIVEN: [[0,2,2],[0,0,2],[0,0,2]]
	 * WHEN: moveLeft
	 * THEN: [[4,0,0],[2,0,0],[2,0,0]]
	 */
	@Test
	public void shiftMerge() {
		int[][] first = ForTesting.HALF_FULL_TO_THE_LEFT;
		int[][] result = ForTesting.HALF_FULL_TO_THE_LEFT_RESULT;
		Game2048 game = new Game2048(first);
		game.moveLeft();
		assertArrayEquals(result, game.getBoard() );
	}
	
	/*
	 * GIVEN: [[0,2,0],[0,2,0],[0,2,0]]
	 * WHEN: moveLeft
	 * THEN: [[2,0,0],[2,0,0],[2,0,0]]
	 */
	@Test
	public void shiftNoMerge() {
		int[][] first = ForTesting.HALF_FULL_MEDIUM;
		int[][] result = ForTesting.HALF_FULL;
		Game2048 game = new Game2048(first);
		game.moveLeft();
		assertArrayEquals(result, game.getBoard() );
	}
	

}
