package uo.mp.lab01.game.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.Game2048;
import uo.mp.lab01.game.model.util.ForTesting;

/**
 * Scenarios:
 * - new game
 */
public class Game2048DefaultConstructorTest {

    @Test
    /**
     * GIVEN:
     * WHEN: Create new game with default constructor
     * THEN: Empty board
     */
    public void testDefaultConstructor() {
	Game2048 g = new Game2048();
	assertArrayEquals(ForTesting.EMPTY, g.getBoard());
    }
}
