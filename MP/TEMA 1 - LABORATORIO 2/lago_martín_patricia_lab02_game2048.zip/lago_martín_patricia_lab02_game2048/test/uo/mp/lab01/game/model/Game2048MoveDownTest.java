package uo.mp.lab01.game.model;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import uo.mp.lab01.game.model.util.ForTesting;

/* 
 * Possible scenarios:
 * 1- One merge is possible
 * 2- No merge is possible
 * 3- Merges on a big board
 */

public class Game2048MoveDownTest {
	
	/*
	 * GIVEN: [[0,2,2],[0,0,2],[0,0,2]]
	 * WHEN: moveDown
	 * THEN: [[0,0,0],[0,0,2],[0,2,4]]
	 */
	@Test
	public void oneMerge() {
		int[][] first = ForTesting.HALF_FULL_DOWN;
		int[][] result = ForTesting.HALF_FULL_DOWN_RESULT;
		Game2048 game = new Game2048(first);
		game.moveDown();
		assertArrayEquals(result, game.getBoard() );
	}
	
	/*
	 * GIVEN: [[0,2,2],[8,0,0],[0,0,0]]
	 * WHEN: moveDown
	 * THEN: [[0,0,0],[0,0,0],[8,2,2]]
	 */
	@Test
	public void noMerge() {
		int[][] first = ForTesting.HALF_FULL_DOWN_NO;
		int[][] result = ForTesting.HALF_FULL_DOWN_NO_RESULT;
		Game2048 game = new Game2048(first);
		game.moveDown();
		assertArrayEquals(result, game.getBoard() );
	}
	

}
