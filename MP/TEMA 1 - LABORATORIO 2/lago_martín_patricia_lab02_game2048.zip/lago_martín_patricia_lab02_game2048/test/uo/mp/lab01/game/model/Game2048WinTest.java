package uo.mp.lab01.game.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.util.ForTesting;

public class Game2048WinTest {
	/**
	 * Scenarios: 
	 * 1- Board with winning number
	 * 2- Board without winning number
	 */
	@Test
	/*
	 * GIVEN: board with a winning number
	 * WHEN: run the win method
	 * THEN: return true
	 */
	public void winningBoard() {
		Game2048 game = new Game2048(ForTesting.HALF_FULL_2048);
		assertTrue(game.win());
	}

	@Test
	/*
	 * GIVEN: board with a winning number
	 * WHEN: run the win method
	 * THEN: return true
	 */
	public void notWinningBoard() {
		Game2048 game = new Game2048(ForTesting.HALF_FULL);
		assertFalse(game.win());
	}
}
