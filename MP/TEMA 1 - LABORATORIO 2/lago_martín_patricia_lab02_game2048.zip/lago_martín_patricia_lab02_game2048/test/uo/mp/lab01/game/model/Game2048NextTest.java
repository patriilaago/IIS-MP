package uo.mp.lab01.game.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.util.ForTesting;


/**
 * Scenarios:
 * 1- Empty board  
 * 2- Board with some elements 
 * 3- Board completely full
 */
public class Game2048NextTest {

    @Test
    /**
     * GIVEN: an empty matrix
     * WHEN: run next
     * THEN: return true
     */
    public void emptyBoard() {
   	 	Game2048 game=new Game2048(ForTesting.EMPTY);
   	 	assertTrue(game.next());
    }

    @Test
    /**
     * GIVEN: a matrix that is not full
     * WHEN: run next
     * THEN: return true
     */
    public void halfFull() {
    	Game2048 game=new Game2048(ForTesting.HALF_FULL);
   	 	assertTrue(game.next());
    }

    @Test
    /**
     * GIVEN: a full matrix
     * WHEN: run next
     * THEN: return false
     */
    public void fullMatrix() {
    	Game2048 game=new Game2048(ForTesting.FULL);
  	  	assertFalse(game.next());
    }

}
