package uo.mp.lab01.game.model;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.Game2048;
import uo.mp.lab01.game.model.util.ForTesting;

/**
 * Scenarios:
 * - valid boards (lower limit 3, intermediate dimension 4, higher limit 5)
 * - invalid board: not squared
 * - invalid board: dimension under 3
 * - invalid board: dimension over 5
 * - invalid board: content not a multiple of 2
 * - invalid null board
 */
public class Game2048ConstructorWithBoardTest {

    @Test
    /**
     * GIVEN: A valid matrix 3x3
     * WHEN: Create a Game with the board
     * THEN: the board is set to the argument
     */
    public void testLowerLimit() {
    	Game2048 game = new Game2048(ForTesting.HALF_FULL);
    	assertArrayEquals(ForTesting.HALF_FULL,game.getBoard());
    }

    @Test
    /**
     * GIVEN: A valid matrix 5x5
     * WHEN: Create a Game with the board
     * THEN: the board is set to the argument
     */
    public void testUpperLimit() {
    	Game2048 game = new Game2048(ForTesting.BIG_HALF_FULL);
    	assertArrayEquals(ForTesting.BIG_HALF_FULL,game.getBoard());

    }

    @Test
    /**
     * GIVEN: A valid matrix 4x4
     * WHEN: Create a Game with the board
     * THEN: the board is set to the argument
     */
    public void testIntermediateDimension() {
    	Game2048 game = new Game2048(ForTesting.MEDIUM_HALF_FULL);
    	assertArrayEquals(ForTesting.MEDIUM_HALF_FULL,game.getBoard());
    }

    @Test
    /**
     * GIVEN: An invalid matrix 2x2
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    public void testDimensionUnder3() {
    	Game2048 game = new Game2048(ForTesting.TINY_BOARD);
    	assertArrayEquals(ForTesting.EMPTY,game.getBoard());
    }

    @Test
    /**
     * GIVEN: An invalid matrix 6x6
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    public void testDimensionOver5() {
    	Game2048 game = new Game2048(ForTesting.TOO_BIG_BOARD);
    	assertArrayEquals(ForTesting.EMPTY,game.getBoard());
    }

    @Test
    /**
     * GIVEN: An invalid matrix 3x4
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    public void testNotSquaredDimension() {
    	Game2048 game = new Game2048(ForTesting.NOT_SQUARED_BOARD);
    	assertArrayEquals(ForTesting.EMPTY,game.getBoard());
    }

    @Test
    /**
     * GIVEN: An matrix 4x4 containing an invalid value (not power of 2)
     * WHEN: Create a Game with the board
     * THEN: the board is set to default board
     */
    public void testInvalidContent() {
    	Game2048 game = new Game2048(ForTesting.CORRUPTED_BOARD);
    	assertArrayEquals(ForTesting.EMPTY,game.getBoard());
    }

    @Test
    /**
     * GIVEN: A null matrix
     * WHEN: Create a Game with the board
     * THEN: IllegalArgumentException expected
     */
    public void testNullContent() {

	Assertions.assertThrows(IllegalArgumentException.class, () -> {
	    new Game2048(null);
	}, "IllegalArgumentException was expected");
    }
}
