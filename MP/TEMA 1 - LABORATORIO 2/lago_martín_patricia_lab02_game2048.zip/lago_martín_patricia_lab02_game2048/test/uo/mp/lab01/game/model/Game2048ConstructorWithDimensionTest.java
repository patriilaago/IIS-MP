package uo.mp.lab01.game.model;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.util.ForTesting;

/**
 * Scenarios:
 * - Valid boards (lower limit 3, intermediate dimension 4, higher limit 5)
 * - Invalid board: dimension over 5
 * - Invalid board: dimension under 3
 */
public class Game2048ConstructorWithDimensionTest {

    @Test
    /**
     * GIVEN:a matrix size equal to 3
     * WHEN: running the constructor with dimension 3
     * THEN: the board is set to the argument
     */
    public void testLowerLimit() {
    	Game2048 game = new Game2048(3);
    	assertArrayEquals(ForTesting.EMPTY, game.getBoard());
    }

    @Test
    /**
     * GIVEN:a matrix size equal to 4
     * WHEN: running the constructor with dimension 4
     * THEN: the board is set to the argument
     */
    public void testIntermediateDimension() {
    	Game2048 game = new Game2048(4);
    	assertArrayEquals(ForTesting.MEDIUM_EMPTY, game.getBoard());
    }
    
    @Test
    /**
     * GIVEN:a matrix size equal to 5
     * WHEN: running the constructor with dimension 5
     * THEN: the board is set to the argument
     */
    public void testHigherLimit() {
    	Game2048 game = new Game2048(5);
    	assertArrayEquals(ForTesting.BIG_EMTPY, game.getBoard());
    }

    @Test
    /**
     * GIVEN:
     * WHEN:
     * THEN:
     */
    public void overMaxLimit() {
    	try {
    		Game2048 game = new Game2048(2);
    		fail();
    	}
    	catch (Exception e) {
    		assertEquals("The size of the board cannot be lower than 3 or higher than 5", e.getMessage());
		}
    }

    @Test
    /**
     * GIVEN:
     * WHEN:
     * THEN:
     */
    public void belowMinLimit() {
    	try {
    		Game2048 game = new Game2048(8);
    		fail();
    	}
    	catch (Exception e) {
    		assertEquals("The size of the board cannot be lower than 3 or higher than 5", e.getMessage());
		}
    }

}
