package uo.mp.lab01.game.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import uo.mp.lab01.game.model.util.ForTesting;

public class Game2048ToStringTest {

	/**
	 * Scenarios: 
	 * - Three valid boards
	 */
	
	@Test
	/*
	 * GIVEN: a board with some elements
	 * WHEN: run the toString method
	 * THEN: return string corresponding to the board
	 */
	public void firstBoard() {
		Game2048 game = new Game2048(ForTesting.HALF_FULL);
		String result = "2....0....0....\\n 2....0....0....\\n 2....0....0....\\n ";
		assertEquals(result,game.toString());
	}
	
	@Test
	/*
	 * GIVEN: a board with some elements
	 * WHEN: run the toString method
	 * THEN: return string corresponding to the board
	 */
	public void secondBoard() {
		Game2048 game = new Game2048(ForTesting.HALF_FULL_TO_THE_LEFT_RESULT);
		String result = "4....0....0....\\n 2....0....0....\\n 2....0....0....\\n ";
		assertEquals(result,game.toString());
	}
	
	@Test
	/*
	 * GIVEN: a board with some elements
	 * WHEN: run the toString method
	 * THEN: return string corresponding to the board
	 */
	void thirdBoard() {
		Game2048 game = new Game2048(ForTesting.HALF_FULL_2048);
		String result = "2....0....0....0....0....\\n 2....0....0....0....0....\\n 2....0....2048....0....0....\\n 2....0....0....0....0....\\n 2....0....0....0....0....\\n ";
		assertEquals(result,game.toString());
	}
}
